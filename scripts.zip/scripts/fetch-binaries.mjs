#!/usr/bin/env node
/**
 * Fetches the helper programs SARAB ships with (yt-dlp, ffmpeg, ffprobe, deno) into src-tauri/binaries/,
 * named the way Tauri's `bundle.externalBin` wants them:  <name>-<target-triple>[.exe]
 *   e.g.  yt-dlp-x86_64-pc-windows-msvc.exe
 *
 * Tauri then packs them next to SARAB's executable, so the finished app needs no download at runtime.
 *
 * It runs automatically before `npm run tauri dev|build` (see "pretauri" in package.json) and as part of
 * `beforeBuildCommand` (tauri.conf.json, which also knows the --target of a cross build).
 * Files that are already present are left alone, so it is instant after the first run.
 *
 *   npm run engine                  fetch whatever is missing for this machine
 *   npm run engine:update           re-download everything (newest yt-dlp: do this before each release build)
 *   node scripts/fetch-binaries.mjs --target aarch64-apple-darwin     another target
 *   node scripts/fetch-binaries.mjs --channel stable                  yt-dlp stable instead of nightly
 *   SARAB_YTDLP_CHANNEL=stable      same as --channel
 *
 * yt-dlp comes from its NIGHTLY channel by default: sites like YouTube change often and stable releases lag
 * behind those changes, while nightly builds get the fixes first. (Files that are already there are kept, so to
 * switch channel or refresh yt-dlp run `npm run engine:update`.)
 *   node scripts/fetch-binaries.mjs --dry-run                         show what it would do
 *   SARAB_TARGET=<triple>           same as --target
 *
 * Needs Node 18+ (built-in fetch). No npm dependencies.
 */
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const DEFAULT_OUT = path.join(ROOT, "src-tauri", "binaries");

/** Where yt-dlp comes from, per channel. */
export const YTDLP_CHANNELS = {
  nightly: "https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download",
  stable: "https://github.com/yt-dlp/yt-dlp/releases/latest/download",
};
const FFMPEG_BASE = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest";
const DENO_BASE = "https://github.com/denoland/deno/releases/latest/download";

/** The four programs, as the base names used in tauri.conf.json `externalBin` ("binaries/<name>"). */
export const PROGRAMS = ["yt-dlp", "ffmpeg", "ffprobe", "deno"];

/**
 * Supported targets. `ytdlp` = the release asset to download. `ffmpeg` = which static build to use, or null when no
 * ready-made build exists (macOS): then put `ffmpeg-<triple>` and `ffprobe-<triple>` into src-tauri/binaries yourself.
 */
export const TARGETS = {
  "x86_64-pc-windows-msvc": { ytdlp: "yt-dlp.exe", ffmpeg: { arch: "win64", ext: "zip" } },
  "x86_64-unknown-linux-gnu": { ytdlp: "yt-dlp_linux", ffmpeg: { arch: "linux64", ext: "tar.xz" } },
  "aarch64-unknown-linux-gnu": { ytdlp: "yt-dlp_linux_aarch64", ffmpeg: { arch: "linuxarm64", ext: "tar.xz" } },
  "x86_64-apple-darwin": { ytdlp: "yt-dlp_macos", ffmpeg: null },
  "aarch64-apple-darwin": { ytdlp: "yt-dlp_macos", ffmpeg: null },
};

const isWindows = (triple) => triple.includes("windows");
/** Name of a program inside archives / on disk without the triple: "ffmpeg" -> "ffmpeg.exe" on Windows. */
export const plainName = (name, triple) => (isWindows(triple) ? `${name}.exe` : name);
/** Name Tauri expects in src-tauri/binaries/: "ffmpeg" -> "ffmpeg-x86_64-pc-windows-msvc.exe". */
export const sidecarName = (name, triple) => `${name}-${triple}${isWindows(triple) ? ".exe" : ""}`;

/** Which target to build for: --target, then Tauri's own variable (set while it runs hooks), then this machine. */
export function detectTarget(argv = process.argv, env = process.env) {
  const i = argv.indexOf("--target");
  if (i >= 0 && argv[i + 1]) return argv[i + 1];
  if (env.TAURI_ENV_TARGET_TRIPLE) return env.TAURI_ENV_TARGET_TRIPLE;
  if (env.SARAB_TARGET) return env.SARAB_TARGET;
  const out = execFileSync("rustc", ["-vV"], { encoding: "utf8" });
  const m = /^host:\s*(\S+)/m.exec(out);
  if (!m) throw new Error("Could not work out the target triple from `rustc -vV`. Pass --target <triple>.");
  return m[1];
}

/** Which yt-dlp channel: --channel, then SARAB_YTDLP_CHANNEL, then nightly. */
export function detectChannel(argv = process.argv, env = process.env) {
  const i = argv.indexOf("--channel");
  const channel = (i >= 0 && argv[i + 1]) || env.SARAB_YTDLP_CHANNEL || "nightly";
  if (!YTDLP_CHANNELS[channel]) throw new Error(`Unknown yt-dlp channel "${channel}". Use one of: ${Object.keys(YTDLP_CHANNELS).join(", ")}.`);
  return channel;
}

/** What is already there and what has to be fetched. Pure: touches nothing but reads the folder. */
export function plan(triple, outDir, force = false, channel = "nightly") {
  const target = TARGETS[triple];
  if (!target) {
    throw new Error(
      `No ready-made engine for target "${triple}".\n` +
        `Supported: ${Object.keys(TARGETS).join(", ")}.\n` +
        `For anything else, put these files into ${outDir} yourself:\n` +
        PROGRAMS.map((n) => `  ${sidecarName(n, triple)}`).join("\n"),
    );
  }
  const files = Object.fromEntries(PROGRAMS.map((n) => [n, path.join(outDir, sidecarName(n, triple))]));
  const present = (n) => fs.existsSync(files[n]) && fs.statSync(files[n]).size > 0;
  const need = (n) => force || !present(n);
  const steps = [];
  if (need("yt-dlp")) steps.push("yt-dlp");
  if (need("ffmpeg") || need("ffprobe")) steps.push("ffmpeg");
  if (need("deno")) steps.push("deno");
  return { triple, target, files, steps, channel, ytdlpBase: YTDLP_CHANNELS[channel] };
}

// ---------------------------------------------------------------------------------------------------------------
// Archives
// ---------------------------------------------------------------------------------------------------------------

/**
 * Pull files out of a .zip held in memory, matching by file name in any folder.
 * Handles "stored" and "deflate" entries (all that these archives use); no zip64 (nothing here is > 4 GB).
 * Returns Map<fileName, Buffer>.
 */
export function unzipSelected(buf, wanted) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("Not a zip file (or it is corrupt).");
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const found = new Map();
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error("Corrupt zip directory.");
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString("utf8", off + 46, off + 46 + nameLen);
    off += 46 + nameLen + extraLen + commentLen;

    const base = name.split("/").pop();
    if (name.endsWith("/") || !wanted.has(base)) continue;
    if (compSize === 0xffffffff) throw new Error("zip64 archives are not supported.");
    const start = localOff + 30 + buf.readUInt16LE(localOff + 26) + buf.readUInt16LE(localOff + 28);
    const data = buf.subarray(start, start + compSize);
    if (method === 0) found.set(base, Buffer.from(data));
    else if (method === 8) found.set(base, zlib.inflateRawSync(data));
    else throw new Error(`Unsupported zip compression (method ${method}).`);
  }
  return found;
}

/** yt-dlp publishes a SHA2-256SUMS file with lines like "<64 hex>  yt-dlp.exe". */
export function parseSums(text) {
  const sums = new Map();
  for (const line of text.split(/\r?\n/)) {
    const m = /^([0-9a-fA-F]{64})\s+\*?(.+?)\s*$/.exec(line);
    if (m) sums.set(m[2], m[1].toLowerCase());
  }
  return sums;
}

// ---------------------------------------------------------------------------------------------------------------
// Download and write
// ---------------------------------------------------------------------------------------------------------------

async function download(url, label, log) {
  const res = await fetch(url, { headers: { "user-agent": "SARAB-build" }, redirect: "follow" });
  if (!res.ok) throw new Error(`${label}: HTTP ${res.status} for ${url}`);
  const total = Number(res.headers.get("content-length")) || 0;
  const chunks = [];
  let done = 0;
  let shown = -1;
  for await (const chunk of res.body) {
    chunks.push(chunk);
    done += chunk.length;
    if (total) {
      const pct = Math.floor((done * 100) / total / 10) * 10; // every 10 %
      if (pct !== shown) {
        shown = pct;
        log(`  ${label}: ${pct}%`);
      }
    }
  }
  return Buffer.concat(chunks);
}

function writeProgram(file, buf, triple) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.part`;
  fs.writeFileSync(tmp, buf);
  if (!isWindows(triple)) fs.chmodSync(tmp, 0o755);
  fs.renameSync(tmp, file); // never leaves a half-written program behind
}

async function verifyYtdlp(buf, asset, base, log) {
  let text;
  try {
    const res = await fetch(`${base}/SHA2-256SUMS`, { headers: { "user-agent": "SARAB-build" } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    text = await res.text();
  } catch (e) {
    log(`  ! could not fetch yt-dlp checksums (${e.message}); skipping verification`);
    return;
  }
  const want = parseSums(text).get(asset);
  if (!want) {
    log(`  ! no checksum listed for ${asset}; skipping verification`);
    return;
  }
  const got = createHash("sha256").update(buf).digest("hex");
  if (got !== want) throw new Error(`yt-dlp checksum mismatch (expected ${want}, got ${got}). The download is corrupt: run it again.`);
  log("  yt-dlp checksum OK");
}

async function getYtdlp(p, log) {
  log(`yt-dlp (${p.channel} channel)`);
  const buf = await download(`${p.ytdlpBase}/${p.target.ytdlp}`, "yt-dlp", log);
  await verifyYtdlp(buf, p.target.ytdlp, p.ytdlpBase, log);
  writeProgram(p.files["yt-dlp"], buf, p.triple);
}

async function getFfmpeg(p, log) {
  const ff = p.target.ffmpeg;
  if (!ff) {
    throw new Error(
      `There is no ready-made ffmpeg download for ${p.triple}.\n` +
        `Put static builds of ffmpeg and ffprobe into ${path.dirname(p.files.ffmpeg)} named:\n` +
        `  ${path.basename(p.files.ffmpeg)}\n  ${path.basename(p.files.ffprobe)}`,
    );
  }
  log("ffmpeg + ffprobe (large download)");
  const buf = await download(`${FFMPEG_BASE}/ffmpeg-master-latest-${ff.arch}-gpl.${ff.ext}`, "ffmpeg", log);
  if (ff.ext === "zip") {
    const names = new Set([plainName("ffmpeg", p.triple), plainName("ffprobe", p.triple)]);
    const got = unzipSelected(buf, names);
    for (const n of ["ffmpeg", "ffprobe"]) {
      const data = got.get(plainName(n, p.triple));
      if (!data) throw new Error(`${plainName(n, p.triple)} not found inside the ffmpeg archive.`);
      writeProgram(p.files[n], data, p.triple);
    }
  } else {
    // .tar.xz: let the system `tar` (with xz support) do it.
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "sarab-ffmpeg-"));
    try {
      const archive = path.join(tmp, "ffmpeg.tar.xz");
      fs.writeFileSync(archive, buf);
      execFileSync("tar", ["-xJf", archive, "-C", tmp, "--strip-components=2", "--wildcards", "*/bin/ffmpeg", "*/bin/ffprobe"], { stdio: "inherit" });
      for (const n of ["ffmpeg", "ffprobe"]) writeProgram(p.files[n], fs.readFileSync(path.join(tmp, n)), p.triple);
    } finally {
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  }
}

async function getDeno(p, log) {
  log("deno (JavaScript runtime yt-dlp uses for YouTube)");
  const buf = await download(`${DENO_BASE}/deno-${p.triple}.zip`, "deno", log);
  const name = plainName("deno", p.triple);
  const data = unzipSelected(buf, new Set([name])).get(name);
  if (!data) throw new Error(`${name} not found inside the deno archive.`);
  writeProgram(p.files.deno, data, p.triple);
}

/** Make sure every program exists for `triple` in `outDir`. */
export async function ensureBinaries({ triple, outDir = DEFAULT_OUT, force = false, dryRun = false, channel = "nightly", log = console.log } = {}) {
  const p = plan(triple, outDir, force, channel);
  if (p.steps.length === 0) {
    log(`SARAB engine: all programs present for ${triple} (${path.relative(ROOT, outDir) || outDir}).`);
    return p;
  }
  log(`SARAB engine for ${triple}: ${p.steps.join(", ")} ${dryRun ? "would be fetched" : "to fetch"}.`);
  if (dryRun) {
    for (const s of p.steps) {
      if (s === "yt-dlp") log(`  yt-dlp (${p.channel}) -> ${p.ytdlpBase}/${p.target.ytdlp}`);
      if (s === "ffmpeg") log(p.target.ffmpeg ? `  ffmpeg, ffprobe -> ${FFMPEG_BASE}/ffmpeg-master-latest-${p.target.ffmpeg.arch}-gpl.${p.target.ffmpeg.ext}` : "  ffmpeg, ffprobe -> (no download for this target; provide the files yourself)");
      if (s === "deno") log(`  deno -> ${DENO_BASE}/deno-${p.triple}.zip`);
    }
    for (const n of PROGRAMS) log(`  will be saved as ${path.basename(p.files[n])}`);
    return p;
  }
  fs.mkdirSync(outDir, { recursive: true });
  for (const s of p.steps) {
    if (s === "yt-dlp") await getYtdlp(p, log);
    if (s === "ffmpeg") await getFfmpeg(p, log);
    if (s === "deno") await getDeno(p, log);
  }
  log("SARAB engine ready.");
  return p;
}

// ---------------------------------------------------------------------------------------------------------------
// Command line
// ---------------------------------------------------------------------------------------------------------------

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2);
  try {
    await ensureBinaries({
      triple: detectTarget(process.argv),
      force: args.includes("--force"),
      dryRun: args.includes("--dry-run"),
      channel: detectChannel(process.argv),
    });
  } catch (e) {
    console.error(`\nSARAB engine setup failed:\n${e.message}\n`);
    console.error("Check your internet connection and run `npm run engine` again, or place the files in src-tauri/binaries by hand.");
    process.exit(1);
  }
}

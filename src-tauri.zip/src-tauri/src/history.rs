//! Finished downloads, persisted to history.json so the History tab survives restarts.

use serde::{Deserialize, Serialize};
use std::{path::PathBuf, sync::Mutex};
use tauri::{AppHandle, Manager};

const MAX_ENTRIES: usize = 500;
static LOCK: Mutex<()> = Mutex::new(());

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Entry {
    pub id: String,
    pub url: String,
    pub title: String,
    pub thumbnail: Option<String>,
    pub format: String,
    pub quality: String,
    pub file_path: Option<String>,
    /// Unix time in milliseconds.
    pub finished_at: u64,
}

fn file(app: &AppHandle) -> PathBuf {
    app.path().app_config_dir().expect("config dir").join("history.json")
}

fn read(app: &AppHandle) -> Vec<Entry> {
    std::fs::read_to_string(file(app))
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}

fn write(app: &AppHandle, list: &[Entry]) {
    let path = file(app);
    if let Some(dir) = path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    if let Ok(json) = serde_json::to_string(list) {
        let _ = std::fs::write(path, json);
    }
}

/// Newest first.
pub fn load(app: &AppHandle) -> Vec<Entry> {
    let _g = LOCK.lock().unwrap();
    read(app)
}

pub fn push(app: &AppHandle, e: Entry) {
    let _g = LOCK.lock().unwrap();
    let mut list = read(app);
    list.retain(|x| x.id != e.id);
    list.insert(0, e);
    list.truncate(MAX_ENTRIES);
    write(app, &list);
}

pub fn remove(app: &AppHandle, id: &str) {
    let _g = LOCK.lock().unwrap();
    let mut list = read(app);
    list.retain(|x| x.id != id);
    write(app, &list);
}

pub fn clear(app: &AppHandle) {
    let _g = LOCK.lock().unwrap();
    write(app, &[]);
}

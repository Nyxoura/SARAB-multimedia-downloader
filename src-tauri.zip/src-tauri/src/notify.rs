//! OS notifications, localised to the language the user picked in the app.

use crate::settings;
use tauri::{AppHandle, Manager};
use tauri_plugin_notification::NotificationExt;

/// (title, body) pairs; the Arabic pair is used when the app language is Arabic.
pub fn show(app: &AppHandle, en: (&str, &str), ar: (&str, &str)) {
    let is_ar = settings::current(app).lang.as_deref() == Some("ar");
    let (title, body) = if is_ar { ar } else { en };
    let _ = app.notification().builder().title(title).body(body).show();
}

pub fn window_focused(app: &AppHandle) -> bool {
    app.get_webview_window("main")
        .and_then(|w| w.is_focused().ok())
        .unwrap_or(true)
}

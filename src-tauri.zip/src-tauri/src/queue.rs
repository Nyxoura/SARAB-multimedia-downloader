//! Download queue: ONE download at a time, strictly in the order links were added.
//! A single worker task drains a FIFO channel, so there is no concurrency setting and no
//! race over who goes next. Also handles cancellation, yt-dlp supervision and UI events.

use crate::{binaries, history, notify, pacing, settings, ytdlp};
use serde::{Deserialize, Serialize};
use std::{
    collections::{HashMap, HashSet},
    process::Stdio,
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc, Mutex,
    },
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter};
use tokio::{
    io::{AsyncBufReadExt, BufReader},
    sync::mpsc,
};
use tokio_util::sync::CancellationToken;

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct DownloadRequest {
    pub id: String,
    pub url: String,
    /// mp4 | mp3 | audio
    pub format: String,
    /// best | 2160 | 1080 | 720 | 480
    pub quality: String,
    pub dir: String,
    pub cookies_file: Option<String>,
    /// "chrome" | "edge" | "firefox": read cookies straight from that browser (wins over the file).
    #[serde(default)]
    pub cookies_browser: Option<String>,
    pub single_video: bool,
    pub convert_mp4: bool,
    /// Optional clip, as typed by the user (e.g. "1:30"). None = from the start / to the end.
    #[serde(default)]
    pub trim_start: Option<String>,
    #[serde(default)]
    pub trim_end: Option<String>,
}

#[derive(Serialize, Clone, Default)]
#[serde(rename_all = "camelCase")]
pub struct Update {
    pub id: String,
    /// queued | downloading | done | error | cancelled
    pub status: String,
    pub percent: Option<f64>,
    pub speed: Option<f64>,
    pub eta: Option<f64>,
    pub title: Option<String>,
    pub thumbnail: Option<String>,
    pub file_path: Option<String>,
    pub error: Option<String>,
    /// yt-dlp's original wording for a sign-in request or vague failure, shown under the message.
    pub detail: Option<String>,
}

#[derive(Serialize, Clone)]
struct LogLine {
    id: String,
    line: String,
}

struct Finished {
    path: Option<String>,
    title: Option<String>,
    thumbnail: Option<String>,
}

enum Outcome {
    Done(Finished),
    Cancelled,
    /// (error code, yt-dlp's own wording when our message can't fully explain it)
    Failed(String, Option<String>),
}

pub struct Queue {
    tokens: Mutex<HashMap<String, CancellationToken>>,
    running: Mutex<Option<String>>,
    tx: mpsc::UnboundedSender<DownloadRequest>,
}

static COUNTER: AtomicU64 = AtomicU64::new(0);

fn new_id() -> String {
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    format!("{:x}-{:x}", nanos, COUNTER.fetch_add(1, Ordering::Relaxed))
}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
}

impl Queue {
    /// Creates the queue and starts its single worker.
    pub fn new(app: AppHandle) -> Arc<Self> {
        let (tx, mut rx) = mpsc::unbounded_channel::<DownloadRequest>();
        let q = Arc::new(Self { tokens: Mutex::new(HashMap::new()), running: Mutex::new(None), tx });
        let worker = q.clone();
        tauri::async_runtime::spawn(async move {
            while let Some(req) = rx.recv().await {
                run(&app, &worker, req).await;
            }
        });
        q
    }

    /// Put a request at the back of the line.
    pub fn submit(&self, app: &AppHandle, req: DownloadRequest) {
        self.tokens.lock().unwrap().insert(req.id.clone(), CancellationToken::new());
        emit(app, Update { id: req.id.clone(), status: "queued".into(), ..Default::default() });
        let _ = self.tx.send(req);
    }

    pub fn cancel(&self, app: &AppHandle, id: &str) {
        if let Some(t) = self.tokens.lock().unwrap().get(id) {
            t.cancel();
        }
        // A waiting item never reaches the worker's cancel branch until its turn, so tell the UI now.
        if self.running.lock().unwrap().as_deref() != Some(id) {
            emit(app, Update { id: id.into(), status: "cancelled".into(), ..Default::default() });
        }
    }
}

/// "90", "1:30", "01:02:30", "1:30.5" -> seconds. Strict on purpose: the text ends up on a command line.
fn parse_secs(s: &str) -> Option<f64> {
    let s = s.trim();
    if s.is_empty() || s.len() > 12 || !s.chars().all(|c| c.is_ascii_digit() || c == ':' || c == '.') {
        return None;
    }
    let parts: Vec<&str> = s.split(':').collect();
    if parts.len() > 3 {
        return None;
    }
    let mut total = 0.0;
    for (i, p) in parts.iter().enumerate() {
        let v: f64 = p.parse().ok()?;
        if i > 0 && v >= 60.0 {
            return None; // "1:75" is not a time
        }
        total = total * 60.0 + v;
    }
    Some(total)
}

/// Validate the optional clip range. Empty boxes become None. Errors are codes the UI translates:
/// `trim_invalid` (not a time) or `trim_order` (end is not after start).
pub fn clean_trim(start: Option<String>, end: Option<String>) -> Result<(Option<String>, Option<String>), String> {
    let clean = |v: Option<String>| v.map(|x| x.trim().to_string()).filter(|x| !x.is_empty());
    let (s, e) = (clean(start), clean(end));
    if s.is_none() && e.is_none() {
        return Ok((None, None));
    }
    let from = match &s {
        Some(v) => parse_secs(v).ok_or("trim_invalid")?,
        None => 0.0,
    };
    let to = match &e {
        Some(v) => parse_secs(v).ok_or("trim_invalid")?,
        None => f64::INFINITY,
    };
    if to <= from {
        return Err("trim_order".into());
    }
    Ok((s, e))
}

/// Build requests from the saved settings (the Download tab's current choices) and queue them in order.
/// Returns how many were queued, or an error code if no download folder is set yet.
/// A clip range only applies when exactly one link is queued. Error codes: `no_folder`, `trim_invalid`, `trim_order`.
pub fn enqueue(
    app: &AppHandle,
    q: &Arc<Queue>,
    urls: Vec<String>,
    trim_start: Option<String>,
    trim_end: Option<String>,
) -> Result<usize, String> {
    let s = settings::current(app);
    let Some(dir) = s.download_dir.clone() else { return Err("no_folder".into()) };
    let (trim_start, trim_end) = if urls.len() == 1 { clean_trim(trim_start, trim_end)? } else { (None, None) };
    let browser = s.cookies_browser.clone();
    let cookies = if browser.is_some() { None } else if s.use_cookies { s.cookies_file.clone() } else { None };
    let mut n = 0;
    for url in urls {
        let req = DownloadRequest {
            id: new_id(),
            url,
            format: s.format.clone(),
            quality: s.quality.clone(),
            dir: dir.clone(),
            cookies_file: cookies.clone(),
            cookies_browser: browser.clone(),
            single_video: s.single_video,
            convert_mp4: s.convert_mp4,
            trim_start: trim_start.clone(),
            trim_end: trim_end.clone(),
        };
        let _ = app.emit("download://added", req.clone());
        q.submit(app, req);
        n += 1;
    }
    Ok(n)
}

fn emit(app: &AppHandle, u: Update) {
    let _ = app.emit("download://update", u);
}

fn log(app: &AppHandle, id: &str, line: &str) {
    let _ = app.emit("download://log", LogLine { id: id.into(), line: line.into() });
}

async fn run(app: &AppHandle, q: &Arc<Queue>, req: DownloadRequest) {
    let token = q.tokens.lock().unwrap().get(&req.id).cloned();
    let Some(token) = token else { return }; // already handled (e.g. a duplicate after retry)

    let outcome = if token.is_cancelled() {
        Outcome::Cancelled
    } else {
        *q.running.lock().unwrap() = Some(req.id.clone());
        let o = execute(app, &req, &token).await;
        pacing::finished(&req.url); // the pause for the next download from this site counts from here
        *q.running.lock().unwrap() = None;
        o
    };
    q.tokens.lock().unwrap().remove(&req.id);

    let mut u = Update { id: req.id.clone(), ..Default::default() };
    match outcome {
        Outcome::Done(f) => {
            u.status = "done".into();
            u.percent = Some(100.0);
            u.title = f.title.clone();
            u.file_path = f.path.clone();

            // History is written before the UI hears "done", so a refetch always sees it.
            history::push(
                app,
                history::Entry {
                    id: req.id.clone(),
                    url: req.url.clone(),
                    title: f.title.clone().unwrap_or_else(|| req.url.clone()),
                    thumbnail: f.thumbnail,
                    format: req.format.clone(),
                    quality: req.quality.clone(),
                    file_path: f.path,
                    finished_at: now_ms(),
                },
            );

            if settings::current(app).notify_on_done && !notify::window_focused(app) {
                let name = f.title.as_deref().unwrap_or("");
                let en_body = if name.is_empty() { "Your download is ready." } else { name };
                let ar_body = if name.is_empty() { "تحميلك جاهز." } else { name };
                notify::show(app, ("Download complete", en_body), ("اكتمل التحميل", ar_body));
            }
        }
        Outcome::Cancelled => u.status = "cancelled".into(),
        Outcome::Failed(code, detail) => {
            u.status = "error".into();
            u.error = Some(code);
            u.detail = detail;
        }
    }
    emit(app, u);
}

/// Trust yt-dlp's printed path only if it exists; otherwise find the newest file in the
/// download folder whose name contains the video id, e.g. "[SU9HdmjMVM]".
fn locate(file: Option<String>, id: Option<String>, dir: &str) -> Option<String> {
    if file.as_deref().map_or(false, |f| std::path::Path::new(f).exists()) {
        return file;
    }
    let needle = format!("[{}]", id?);
    std::fs::read_dir(dir)
        .ok()?
        .filter_map(|e| e.ok())
        .filter(|e| {
            let name = e.file_name().to_string_lossy().to_string();
            name.contains(&needle) && !name.ends_with(".part") && !name.ends_with(".ytdl")
        })
        .max_by_key(|e| e.metadata().and_then(|m| m.modified()).ok())
        .map(|e| e.path().to_string_lossy().to_string())
        .or(file)
}

/// Names of the files already in the download folder.
fn names_in(dir: &str) -> HashSet<String> {
    std::fs::read_dir(dir)
        .map(|rd| rd.flatten().map(|e| e.file_name().to_string_lossy().to_string()).collect::<HashSet<String>>())
        .unwrap_or_default()
}

/// The extension the finished file normally has for this request.
fn expected_ext(req: &DownloadRequest) -> &'static str {
    match req.format.as_str() {
        "mp3" => "mp3",
        "audio" => "m4a",
        _ => "mp4",
    }
}

/// Stops yt-dlp AND everything it started. On Windows `yt-dlp.exe` is a self-extracting launcher whose real work
/// happens in a child process (and ffmpeg is another), so killing only the launcher would leave the download
/// running, and its .part file locked, in the background.
async fn kill_tree(child: &mut tokio::process::Child) {
    if let Some(pid) = child.id() {
        kill_children_of(pid).await;
    }
    let _ = child.kill().await;
    let _ = child.wait().await; // make sure it is gone, so its file handles are released
}

#[cfg(windows)]
async fn kill_children_of(pid: u32) {
    let pid = pid.to_string();
    let _ = binaries::command(std::path::Path::new("taskkill"))
        .args(["/PID", pid.as_str(), "/T", "/F"])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .await;
}

#[cfg(not(windows))]
async fn kill_children_of(pid: u32) {
    let pid = pid.to_string();
    let _ = tokio::process::Command::new("pkill")
        .args(["-KILL", "-P", pid.as_str()])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .await;
}

/// `.f137.mp4`, `.f251-drc.webm` ...: the per-format pieces yt-dlp downloads before merging them.
fn has_format_tag(lower: &str) -> bool {
    lower.match_indices(".f").any(|(i, _)| {
        let t = &lower[i + 2..];
        let digits = t.chars().take_while(|c| c.is_ascii_digit()).count();
        digits > 0 && matches!(t[digits..].chars().next(), Some('.') | Some('-'))
    })
}

/// Is this (the part of a file name after "[video id]") something yt-dlp only leaves behind unfinished?
fn is_partial(rest: &str) -> bool {
    let r = rest.to_ascii_lowercase();
    r.ends_with(".part")
        || r.ends_with(".ytdl")
        || r.ends_with(".tmp")
        || r.ends_with(".temp")
        || r.contains(".part-frag")
        || r.contains(".temp.")
        || has_format_tag(&r)
}

/// Removes what a cancelled download left in the folder: yt-dlp's resume files (`.part`, `.ytdl`, `.part-FragN`),
/// the per-format pieces it merges, `.temp` files, and any other file this run created for the same video id
/// (cover image, a half-finished merge). A file that was already in the folder before the run is never touched,
/// unless it is unmistakably unfinished (a `.part` left by an earlier attempt). Returns how many were removed.
async fn cleanup_partials(app: &AppHandle, req: &DownloadRequest, id: Option<&str>, before: &HashSet<String>) -> usize {
    let Some(id) = id.filter(|i| !i.is_empty()) else { return 0 }; // cancelled before the download began: nothing exists yet
    let needle = format!("[{id}]");
    let mut removed = 0usize;
    let mut stuck: Vec<String> = Vec::new();

    // Windows can keep a file locked for a moment after its process is gone, so retry a few times.
    for round in 0..8 {
        stuck.clear();
        let Ok(rd) = std::fs::read_dir(&req.dir) else { return removed };
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            let Some(pos) = name.find(needle.as_str()) else { continue };
            let rest = &name[pos + needle.len()..];
            if !(is_partial(rest) || !before.contains(&name)) {
                continue; // a finished file that was there before: not ours to delete
            }
            let path = e.path();
            if !path.is_file() {
                continue;
            }
            match std::fs::remove_file(&path) {
                Ok(()) => {
                    removed += 1;
                    log(app, &req.id, &format!("[sarab] removed unfinished file: {name}"));
                }
                Err(_) => stuck.push(name),
            }
        }
        if stuck.is_empty() || round == 7 {
            break;
        }
        tokio::time::sleep(Duration::from_millis(250)).await;
    }
    for name in &stuck {
        log(app, &req.id, &format!("[sarab] could not delete \"{name}\" (still in use); delete it by hand if it stays"));
    }
    removed
}

/// Runs the download. yt-dlp never overwrites: if the file is already there it says "already downloaded" and
/// stops. When that happens (a file that was in the folder BEFORE we started turns out to be the result), the
/// video is downloaded once more under a free name: "Title [id] - 1.mp4", then "- 2", and so on.
/// Normal downloads take exactly one pass, with exactly the same command as before.
async fn execute(app: &AppHandle, req: &DownloadRequest, token: &CancellationToken) -> Outcome {
    let before = names_in(&req.dir);
    let f = match attempt_resilient(app, req, token, None).await {
        Outcome::Done(f) => f,
        other => return other, // cancelled or failed: nothing to rename
    };

    // Playlists legitimately touch many files, so this applies to single-video downloads only.
    if !req.single_video {
        return Outcome::Done(f);
    }
    let Some(path) = f.path.clone() else { return Outcome::Done(f) };
    let p = std::path::Path::new(&path);
    let stem = p.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let printed_ext = p.extension().map(|e| e.to_string_lossy().to_string()).unwrap_or_default();
    let printed_name = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
    let want = expected_ext(req);

    // Reused = the reported file, or the finished file this request would normally produce, was already there.
    // (For MP3/M4A, yt-dlp can report a leftover intermediate file instead of the existing finished one.)
    let reused = before.contains(&printed_name) || before.contains(&format!("{stem}.{want}"));
    if !reused {
        return Outcome::Done(f);
    }
    // A leftover intermediate file created by this very run (not one the user had) is not a result: remove it.
    if printed_ext != want && !before.contains(&printed_name) {
        let _ = std::fs::remove_file(p);
    }

    let dir = std::path::Path::new(&req.dir);
    let n = (1u32..)
        .find(|n| {
            !dir.join(format!("{stem} - {n}.{want}")).exists() && !dir.join(format!("{stem} - {n}.{printed_ext}")).exists()
        })
        .unwrap_or(1);
    let name = format!("{stem} - {n}");
    log(app, &req.id, &format!("[sarab] \"{stem}.{want}\" already exists, saving a new copy as \"{name}.{want}\""));

    // "%" has a meaning in yt-dlp output templates, so a literal one in the name must be doubled.
    let template_name = name.replace('%', "%%");
    match attempt_resilient(app, req, token, Some(template_name.as_str())).await {
        Outcome::Done(g) => Outcome::Done(Finished {
            path: g.path.or(f.path),
            title: g.title.or(f.title),
            thumbnail: g.thumbnail.or(f.thumbnail),
        }),
        other => other,
    }
}

/// One line for Details (Logs), e.g. "[sarab] timing: ready 6.0 s · download 12.3 s · finishing 0.9 s · total 19.2 s"
///   ready     = from launching yt-dlp until the file transfer is about to begin: yt-dlp starting up (unpacking itself,
///               antivirus scan) PLUS asking the site about the video. They can't be told apart from here, because
///               SARAB runs yt-dlp quietly and it prints nothing of its own until the lookup is done.
///   download  = the file transfer
///   finishing = merging / converting after the transfer
/// If the run ended before reaching the download (an error), the line says how long it took to get there.
fn timing_line(spawn: Instant, info: Option<Instant>, first_data: Option<Instant>, last_data: Option<Instant>, end: Instant) -> String {
    let total = end.saturating_duration_since(spawn).as_secs_f64();
    if info.is_none() && first_data.is_none() {
        return format!("[sarab] timing: ended after {total:.1} s without reaching the download");
    }
    let span = |a: Option<Instant>, b: Option<Instant>| match (a, b) {
        (Some(a), Some(b)) if b >= a => format!("{:.1} s", (b - a).as_secs_f64()),
        _ => "-".to_string(),
    };
    format!(
        "[sarab] timing: ready {} · download {} · finishing {} · total {total:.1} s",
        span(Some(spawn), info.or(first_data)),
        span(first_data, last_data),
        span(last_data.or(info), Some(end)),
    )
}

/// One download run. If yt-dlp cannot read the chosen browser's cookies (browser open and locking its cookie file,
/// newer Chrome/Edge encryption, no permission...), it tries once more WITHOUT cookies: a public video does not
/// need them. If that is then refused for a sign-in, the cookie problem is reported instead, since that is what
/// the user can fix.
async fn attempt_resilient(app: &AppHandle, req: &DownloadRequest, token: &CancellationToken, name: Option<&str>) -> Outcome {
    let first = attempt(app, req, token, name).await;
    let cookie_trouble = ytdlp::browser_arg(req.cookies_browser.as_deref()).is_some()
        && matches!(&first, Outcome::Failed(code, _) if code == "browser_cookies");
    if !cookie_trouble {
        return first;
    }
    log(app, &req.id, "[sarab] could not read the browser's cookies; trying again without them");
    let mut plain = req.clone();
    plain.cookies_browser = None;
    match attempt(app, &plain, token, name).await {
        Outcome::Failed(code, _) if code == "signin" => first,
        other => other,
    }
}

/// One yt-dlp run. `name` overrides the output file name (without extension); None = the usual template.
async fn attempt(app: &AppHandle, req: &DownloadRequest, token: &CancellationToken, name: Option<&str>) -> Outcome {
    // Cookies are optional. A cookies file that has gone missing must not stop a download that doesn't need it:
    // carry on without cookies (download_args leaves it out). If the site then really asks for a sign-in, the
    // error below says the file is missing.
    if let Some(c) = &req.cookies_file {
        if !std::path::Path::new(c).exists() {
            log(app, &req.id, "[sarab] the chosen cookies file was not found; continuing without cookies");
        }
    }
    // Say plainly which cookies this run uses, so Details (Logs) shows whether a browser is really being read.
    let cookie_source = if let Some(b) = ytdlp::browser_arg(req.cookies_browser.as_deref()) {
        format!("cookies from {b}")
    } else if req.cookies_file.as_deref().map_or(false, |c| std::path::Path::new(c).exists()) {
        "a cookies file".to_string()
    } else {
        "no cookies".to_string()
    };
    log(app, &req.id, &format!("[sarab] using {cookie_source}"));
    // This site answered "too many requests" a moment ago: asking again straight away would only add to the problem,
    // for instance when a whole queue of links would each be refused in turn.
    if ytdlp::recently_rate_limited(&req.url, Duration::from_secs(90)) {
        log(app, &req.id, "[sarab] the site refused us a moment ago (too many requests); not asking again yet");
        return Outcome::Failed("ratelimit".into(), None);
    }
    // Space out a batch: wait until a few seconds have passed since the previous download from this same site
    // ended (what yt-dlp's --sleep-interval does for playlists). A lone download never waits. Cancelling while
    // waiting stops straight away.
    let wait = pacing::wait_needed(&req.url);
    if !wait.is_zero() {
        log(app, &req.id, &format!("[sarab] waiting {:.0} s before the next request to the same site, to avoid being rate-limited", wait.as_secs_f64()));
        tokio::select! {
            _ = tokio::time::sleep(wait) => {}
            _ = token.cancelled() => return Outcome::Cancelled,
        }
    }
    let (args, streams) = ytdlp::download_args(app, req, name);
    // What was already in the folder, so a cancel only ever removes files THIS run created.
    let before = names_in(&req.dir);

    let mut child = match binaries::command(&binaries::resolve(app, "yt-dlp"))
        .args(&args)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return Outcome::Failed("engine_missing".into(), None),
    };
    let stdout = child.stdout.take().unwrap();
    let stderr = child.stderr.take().unwrap();

    // stderr: stream to the log panel, keep everything for error translation.
    let err_task = {
        let (app, id) = (app.clone(), req.id.clone());
        tauri::async_runtime::spawn(async move {
            let mut lines = BufReader::new(stderr).lines();
            let mut all = Vec::<String>::new();
            while let Ok(Some(l)) = lines.next_line().await {
                log(&app, &id, &l);
                all.push(l);
            }
            all
        })
    };

    let mut lines = BufReader::new(stdout).lines();
    let (mut file, mut video_id) = (None::<String>, None::<String>);
    // Id of the video being downloaded right now (changes per item when playlists are allowed).
    let mut current_id = None::<String>;
    let (mut title, mut thumbnail) = (None::<String>, None::<String>);
    let (mut stage, mut last_down) = (0usize, 0f64);
    let mut last_emit = Instant::now() - Duration::from_secs(1);
    // Stage timers, summarised in Details (Logs) when the run ends: when yt-dlp was launched, when it announced the
    // video (lookup done), and when the file transfer started and stopped.
    let t_spawn = Instant::now();
    let (mut t_info, mut t_first_data, mut t_last_data) = (None::<Instant>, None::<Instant>, None::<Instant>);

    loop {
        tokio::select! {
            _ = token.cancelled() => {
                kill_tree(&mut child).await;
                // Cancel means "I don't want this file": remove the .part / merge leftovers too.
                let removed = cleanup_partials(app, req, current_id.as_deref(), &before).await;
                if removed > 0 {
                    log(app, &req.id, &format!("[sarab] cancelled; removed {removed} unfinished file(s)"));
                }
                return Outcome::Cancelled;
            }
            line = lines.next_line() => {
                let Ok(Some(l)) = line else { break };
                let now = Instant::now();
                if t_info.is_none() && l.starts_with("SARAB_INFO|") { t_info = Some(now); }
                if l.starts_with("SARAB_PROGRESS|") {
                    if t_first_data.is_none() { t_first_data = Some(now); }
                    t_last_data = Some(now);
                }
                if let Some(rest) = l.strip_prefix("SARAB_PROGRESS|") {
                    let f: Vec<&str> = rest.split('|').collect();
                    let n = |i: usize| f.get(i).and_then(|s| s.trim().parse::<f64>().ok());
                    let down = n(0).unwrap_or(0.0);
                    let total = n(1).or(n(2)).unwrap_or(0.0);
                    if down < last_down { stage += 1; } // next stream (e.g. audio after video) started
                    last_down = down;
                    if last_emit.elapsed() < Duration::from_millis(150) { continue; }
                    last_emit = Instant::now();
                    let frac = if total > 0.0 { (down / total).clamp(0.0, 1.0) } else { 0.0 };
                    let pct = (stage.min(streams - 1) as f64 + frac) / streams as f64 * 100.0;
                    emit(app, Update {
                        id: req.id.clone(), status: "downloading".into(),
                        percent: Some(pct), speed: n(3), eta: n(4), ..Default::default()
                    });
                } else if let Some(rest) = l.strip_prefix("SARAB_INFO|") {
                    // New video starting (also each item when playlists are allowed): restart the bar.
                    stage = 0;
                    last_down = 0.0;
                    let mut p = rest.splitn(3, '|');
                    let vid = p.next().unwrap_or("").trim().to_string();
                    if !vid.is_empty() && vid != "NA" { current_id = Some(vid); }
                    let thumb = p.next().unwrap_or("").to_string();
                    let name = p.next().unwrap_or("").to_string();
                    thumbnail = thumb.starts_with("http").then(|| thumb.clone());
                    title = Some(name.clone());
                    emit(app, Update {
                        id: req.id.clone(), status: "downloading".into(),
                        title: Some(name),
                        thumbnail: thumb.starts_with("http").then_some(thumb),
                        ..Default::default()
                    });
                } else if let Some(rest) = l.strip_prefix("SARAB_FILE|") {
                    let mut p = rest.splitn(2, '|');
                    video_id = p.next().map(|s| s.trim().to_string());
                    file = p.next().map(|s| s.trim().to_string());
                } else {
                    log(app, &req.id, &l);
                }
            }
        }
    }

    let status = child.wait().await;
    let err_lines = err_task.await.unwrap_or_default();
    log(app, &req.id, &timing_line(t_spawn, t_info, t_first_data, t_last_data, Instant::now()));
    match status {
        Ok(s) if s.success() => {
            ytdlp::clear_rate_limit(&req.url);
            Outcome::Done(Finished {
                path: locate(file, video_id, &req.dir),
                title,
                thumbnail,
            })
        }
        _ => {
            let (mut code, detail) = ytdlp::explain(&err_lines);
            if code == "ratelimit" {
                ytdlp::note_rate_limited(&req.url);
            }
            // The site really needs a sign-in AND the cookies file the user picked has vanished: say that instead.
            if code == "signin" && req.cookies_browser.is_none() && req.cookies_file.as_deref().map_or(false, |c| !std::path::Path::new(c).exists()) {
                code = "cookies_missing".into();
            }
            Outcome::Failed(code, detail)
        }
    }
}

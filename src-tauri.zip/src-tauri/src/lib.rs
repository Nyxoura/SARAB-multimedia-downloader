mod binaries;
mod clipboard;
mod history;
mod hotkeys;
mod notify;
mod pacing;
mod queue;
mod settings;
mod ytdlp;

use queue::{DownloadRequest, Queue};
use std::sync::{Arc, Mutex};
use tauri::{AppHandle, Manager, State};
use tauri_plugin_autostart::{MacosLauncher, ManagerExt as _};
use tauri_plugin_global_shortcut::ShortcutState;
use tauri_plugin_opener::OpenerExt;

#[tauri::command]
fn get_settings(app: AppHandle) -> settings::Settings {
    settings::current(&app)
}

/// Saves settings and applies the ones with side effects (hotkeys, launch on startup).
/// Returns an error code if something couldn't be applied; nothing is saved in that case.
#[tauri::command]
fn save_settings(app: AppHandle, value: settings::Settings) -> Result<(), String> {
    let old = settings::current(&app);

    if value.hotkey_download != old.hotkey_download || value.hotkey_toggle != old.hotkey_toggle {
        hotkeys::apply(&app, &value.hotkey_download, &value.hotkey_toggle).map_err(|e| {
            let _ = hotkeys::apply(&app, &old.hotkey_download, &old.hotkey_toggle);
            e
        })?;
    }
    if value.launch_on_startup != old.launch_on_startup {
        let al = app.autolaunch();
        let r = if value.launch_on_startup { al.enable() } else { al.disable() };
        r.map_err(|_| "autostart_failed".to_string())?;
    }
    settings::update(&app, value).map_err(|e| e.to_string())
}

/// Is the bundled download engine present? (It ships inside the app; nothing is ever downloaded.)
#[tauri::command]
fn check_binaries(app: AppHandle) -> binaries::BinStatus {
    binaries::status(&app)
}

#[tauri::command]
async fn probe_url(app: AppHandle, url: String) -> Result<ytdlp::MediaInfo, String> {
    ytdlp::probe(&app, &url).await
}

/// Queue links (in the given order) using the options currently saved in settings.
/// `trim_start` / `trim_end` optionally clip a single link, e.g. "1:30" and "2:45".
#[tauri::command]
fn enqueue_urls(
    app: AppHandle,
    queue: State<'_, Arc<Queue>>,
    urls: Vec<String>,
    trim_start: Option<String>,
    trim_end: Option<String>,
) -> Result<usize, String> {
    queue::enqueue(&app, queue.inner(), urls, trim_start, trim_end)
}

/// Re-submit an existing request (Retry).
#[tauri::command]
fn start_download(app: AppHandle, queue: State<'_, Arc<Queue>>, req: DownloadRequest) -> Result<(), String> {
    let (trim_start, trim_end) = queue::clean_trim(req.trim_start.clone(), req.trim_end.clone())?;
    queue.submit(&app, DownloadRequest { trim_start, trim_end, ..req });
    Ok(())
}

#[tauri::command]
fn cancel_download(app: AppHandle, queue: State<'_, Arc<Queue>>, id: String) {
    queue.cancel(&app, &id);
}

#[tauri::command]
fn get_history(app: AppHandle) -> Vec<history::Entry> {
    history::load(&app)
}

#[tauri::command]
fn remove_history(app: AppHandle, id: String) {
    history::remove(&app, &id);
}

#[tauri::command]
fn clear_history(app: AppHandle) {
    history::clear(&app);
}

/// Opens a file or a folder with the default app.
#[tauri::command]
fn open_file(app: AppHandle, path: String) -> Result<(), String> {
    if !std::path::Path::new(&path).exists() {
        return Err("file_missing".into());
    }
    app.opener().open_path(path, None::<&str>).map_err(|e| e.to_string())
}

#[tauri::command]
fn show_in_folder(app: AppHandle, path: String) -> Result<(), String> {
    let p = std::path::PathBuf::from(&path);
    if p.exists() && app.opener().reveal_item_in_dir(&p).is_ok() {
        return Ok(());
    }
    // File is gone or couldn't be selected: at least open the folder it lived in.
    match p.parent().filter(|d| d.exists()) {
        Some(dir) => app
            .opener()
            .open_path(dir.to_string_lossy().to_string(), None::<&str>)
            .map_err(|e| e.to_string()),
        None => Err("folder_missing".into()),
    }
}

#[tauri::command]
fn open_data_folder(app: AppHandle) -> Result<(), String> {
    let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let _ = std::fs::create_dir_all(&dir);
    app.opener().open_path(dir.to_string_lossy().to_string(), None::<&str>).map_err(|e| e.to_string())
}

/// Only https links, so the UI can't be tricked into launching arbitrary things.
#[tauri::command]
fn open_url(app: AppHandle, url: String) -> Result<(), String> {
    if !url.starts_with("https://") {
        return Err("bad_url".into());
    }
    app.opener().open_url(url, None::<&str>).map_err(|e| e.to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        // Launched at login with --minimized so it starts out of the way.
        .plugin(tauri_plugin_autostart::init(MacosLauncher::LaunchAgent, Some(vec!["--minimized"])))
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(|app, shortcut, event| {
                    if event.state() == ShortcutState::Pressed {
                        hotkeys::on_press(app, shortcut.id());
                    }
                })
                .build(),
        )
        .setup(|app| {
            let handle = app.handle().clone();
            settings::init(&handle);
            app.manage(Queue::new(handle.clone()));
            app.manage(hotkeys::HotkeyIds(Mutex::new((0, 0))));

            let s = settings::current(&handle);
            if let Err(code) = hotkeys::apply(&handle, &s.hotkey_download, &s.hotkey_toggle) {
                // Another app may own the combination; the user can pick a new one in Settings.
                eprintln!("global hotkeys not registered: {code}");
            }
            clipboard::start_watcher(handle);

            if std::env::args().any(|a| a == "--minimized") {
                if let Some(w) = app.get_webview_window("main") {
                    let _ = w.minimize();
                }
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_settings,
            save_settings,
            check_binaries,
            probe_url,
            enqueue_urls,
            start_download,
            cancel_download,
            get_history,
            remove_history,
            clear_history,
            open_file,
            show_in_folder,
            open_data_folder,
            open_url
        ])
        .run(tauri::generate_context!())
        .expect("error while running SARAB");
}

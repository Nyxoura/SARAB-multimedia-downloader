//! Spacing between consecutive downloads from the same site.
//!
//! yt-dlp's own advice against "429 Too Many Requests" is to wait a few seconds between downloads
//! (`--sleep-interval 5 --max-sleep-interval 10`). That flag works inside ONE yt-dlp process (a playlist), but
//! SARAB starts a fresh process for every link, so the same idea is applied here, between runs:
//!
//!   a download waits until 5-10 seconds (random) have passed since the previous download FROM THE SAME SITE ended.
//!
//! A single download after a quiet spell never waits, pasting a link and pressing Download never waits, and a link
//! from a different site never waits for this one. Only a batch of links to the same site is spread out.

use crate::ytdlp::site_of;
use std::{
    collections::HashMap,
    sync::Mutex,
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};

/// The shortest pause between two downloads from one site.
const GAP_MIN_MS: u64 = 5000;
/// A random extra on top, so back-to-back downloads don't land on a fixed rhythm.
const GAP_JITTER_MS: u64 = 5000;

/// When the last download from each site ended.
static LAST_END: Mutex<Option<HashMap<String, Instant>>> = Mutex::new(None);

/// Call when a download from this link's site has ended (finished, failed or cancelled while running).
pub fn finished(url: &str) {
    if let Some(site) = site_of(url) {
        LAST_END.lock().unwrap().get_or_insert_with(HashMap::new).insert(site, Instant::now());
    }
}

/// How long to wait before starting a download from this link's site. Zero if that site has been quiet for a while.
pub fn wait_needed(url: &str) -> Duration {
    let Some(site) = site_of(url) else { return Duration::ZERO };
    let ended = LAST_END.lock().unwrap().as_ref().and_then(|m| m.get(&site)).copied();
    let Some(ended) = ended else { return Duration::ZERO };
    let jitter = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos() as u64 % GAP_JITTER_MS)
        .unwrap_or(0);
    Duration::from_millis(GAP_MIN_MS + jitter).saturating_sub(ended.elapsed())
}

//! Persistent user settings (settings.json in the app config dir), cached in memory so the
//! clipboard watcher and hotkeys can read them without touching the disk.

use serde::{Deserialize, Serialize};
use std::{path::PathBuf, sync::Mutex};
use tauri::{AppHandle, Manager};

#[derive(Serialize, Deserialize, Clone)]
#[serde(default, rename_all = "camelCase")]
pub struct Settings {
    /// None until the user finishes first-run onboarding.
    pub download_dir: Option<String>,
    /// "dark" | "light"
    pub theme: String,
    /// "ar" | "en". None until first launch picks one from the system language.
    pub lang: Option<String>,

    // Download options (the Download tab controls). Stored here so hotkey and
    // clipboard downloads use exactly what the UI shows.
    /// "mp4" | "mp3" | "audio"
    pub format: String,
    /// "best" | "2160" | "1080" | "720" | "480" (only used for mp4)
    pub quality: String,
    pub use_cookies: bool,
    pub cookies_file: Option<String>,
    /// Read cookies straight from this browser: "chrome" | "edge" | "firefox". Wins over the cookies file.
    pub cookies_browser: Option<String>,
    pub single_video: bool,
    pub convert_mp4: bool,

    // Automation
    pub detect_clipboard: bool,
    pub auto_start: bool,
    pub notify_on_done: bool,
    pub launch_on_startup: bool,

    // Global hotkeys, in global-hotkey syntax ("Shift+A", "Alt+BracketLeft").
    pub hotkey_download: String,
    pub hotkey_toggle: String,

    /// Interface zoom in percent.
    pub ui_scale: u32,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            download_dir: None,
            theme: "dark".into(),
            lang: None,
            format: "mp4".into(),
            quality: "best".into(),
            use_cookies: false,
            cookies_file: None,
            cookies_browser: None,
            single_video: true,
            convert_mp4: true,
            detect_clipboard: true,
            auto_start: true,
            notify_on_done: false,
            launch_on_startup: false,
            hotkey_download: "Shift+A".into(),
            hotkey_toggle: "Alt+BracketLeft".into(),
            ui_scale: 100,
        }
    }
}

fn normalize(mut s: Settings) -> Settings {
    // Older builds stored "system"; the new UI is a Light/Dark toggle.
    if s.theme != "light" {
        s.theme = "dark".into();
    }
    if !["mp4", "mp3", "audio"].contains(&s.format.as_str()) {
        s.format = "mp4".into();
    }
    if !["best", "2160", "1080", "720", "480"].contains(&s.quality.as_str()) {
        s.quality = "best".into();
    }
    if !matches!(s.lang.as_deref(), Some("ar") | Some("en")) {
        s.lang = None;
    }
    if !matches!(s.cookies_browser.as_deref(), Some("chrome") | Some("edge") | Some("firefox")) {
        s.cookies_browser = None;
    }
    s.ui_scale = s.ui_scale.clamp(80, 140);
    s
}

pub struct Store(Mutex<Settings>);

fn file(app: &AppHandle) -> PathBuf {
    app.path().app_config_dir().expect("config dir").join("settings.json")
}

/// Load from disk and register the in-memory copy as managed state. Call once in setup.
pub fn init(app: &AppHandle) {
    let loaded = std::fs::read_to_string(file(app))
        .ok()
        .and_then(|s| serde_json::from_str::<Settings>(&s).ok())
        .unwrap_or_default();
    app.manage(Store(Mutex::new(normalize(loaded))));
}

pub fn current(app: &AppHandle) -> Settings {
    app.state::<Store>().0.lock().unwrap().clone()
}

pub fn update(app: &AppHandle, s: Settings) -> anyhow::Result<()> {
    let s = normalize(s);
    let path = file(app);
    if let Some(dir) = path.parent() {
        std::fs::create_dir_all(dir)?;
    }
    std::fs::write(path, serde_json::to_string_pretty(&s)?)?;
    *app.state::<Store>().0.lock().unwrap() = s;
    Ok(())
}

//! Locates and launches the helper programs (yt-dlp, ffmpeg, ffprobe, deno).
//!
//! They ship INSIDE the app: `bundle.externalBin` in tauri.conf.json packs them next to SARAB's own executable
//! (in installed builds and in `tauri dev` alike), so nothing is downloaded when the app starts.
//! `scripts/fetch-binaries.mjs` puts the right files into src-tauri/binaries/ before every build.

use serde::Serialize;
use std::path::{Path, PathBuf};
use tauri::{AppHandle, Manager};

#[derive(Serialize, Clone)]
pub struct BinStatus {
    pub ytdlp: bool,
    /// ffmpeg AND ffprobe (yt-dlp needs both to merge and convert).
    pub ffmpeg: bool,
    /// JS runtime yt-dlp needs for full YouTube support.
    pub deno: bool,
}

pub fn exe(name: &str) -> String {
    if cfg!(windows) { format!("{name}.exe") } else { name.to_string() }
}

/// The folder the bundled programs live in: next to SARAB's own executable.
pub fn bin_dir(_app: &AppHandle) -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(Path::to_path_buf))
        .unwrap_or_default()
}

/// Where older SARAB versions kept the engine they used to download at first run. Still used if it is there.
fn legacy_dir(app: &AppHandle) -> Option<PathBuf> {
    app.path().app_data_dir().ok().map(|d| d.join("bin"))
}

fn on_path(name: &str) -> Option<PathBuf> {
    let paths = std::env::var_os("PATH")?;
    std::env::split_paths(&paths).map(|d| d.join(exe(name))).find(|p| p.is_file())
}

/// Full path of a helper program, if present: the bundled copy first, then an old downloaded copy, then PATH.
pub fn find(app: &AppHandle, name: &str) -> Option<PathBuf> {
    let file = exe(name);
    [Some(bin_dir(app)), legacy_dir(app)]
        .into_iter()
        .flatten()
        .map(|d| d.join(&file))
        .find(|p| p.is_file())
        .or_else(|| on_path(name))
}

/// Like `find`, but falls back to the bare program name so a missing engine fails with a clear spawn error.
pub fn resolve(app: &AppHandle, name: &str) -> PathBuf {
    find(app, name).unwrap_or_else(|| PathBuf::from(exe(name)))
}

/// A Command with UTF-8 output forced (Arabic titles!) and no console flash on Windows.
pub fn command(path: &Path) -> tokio::process::Command {
    let mut c = tokio::process::Command::new(path);
    c.env("PYTHONIOENCODING", "utf-8").env("PYTHONUTF8", "1");
    #[cfg(windows)]
    c.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    c
}

/// Is the engine in place? Only checks that the files exist: starting yt-dlp just to ask its version
/// would unpack it on every launch and make the app slower to open.
pub fn status(app: &AppHandle) -> BinStatus {
    BinStatus {
        ytdlp: find(app, "yt-dlp").is_some(),
        ffmpeg: find(app, "ffmpeg").is_some() && find(app, "ffprobe").is_some(),
        deno: find(app, "deno").is_some(),
    }
}

//! Everything that knows how to talk to yt-dlp: probing, argument building, error translation.

use crate::{binaries, queue::DownloadRequest, settings};
use serde::Serialize;
use std::{
    collections::HashMap,
    process::Stdio,
    sync::Mutex,
    time::{Duration, Instant},
};
use tauri::AppHandle;

#[derive(Serialize)]
pub struct MediaInfo {
    pub title: String,
    pub thumbnail: Option<String>,
    pub duration: Option<f64>,
    pub uploader: Option<String>,
    /// Site the media comes from, e.g. "youtube.com".
    pub platform: Option<String>,
    /// Available video heights, tallest first. Empty for audio-only sources.
    pub heights: Vec<u32>,
}

fn add(a: &mut Vec<String>, xs: &[&str]) {
    a.extend(xs.iter().map(|s| s.to_string()));
}

/// Flags every yt-dlp call needs: where ffmpeg and the JS runtime live.
fn engine_args(app: &AppHandle) -> Vec<String> {
    let mut a = Vec::new();
    // Without this, yt-dlp encodes piped output with the Windows code page and silently drops Arabic characters.
    add(&mut a, &["--encoding", "utf-8"]);
    // The folder holding ffmpeg (ffprobe sits next to it), so yt-dlp can merge and convert.
    if let Some(dir) = binaries::find(app, "ffmpeg").and_then(|p| p.parent().map(|d| d.to_path_buf())) {
        add(&mut a, &["--ffmpeg-location", dir.to_string_lossy().as_ref()]);
    }
    if let Some(deno) = binaries::find(app, "deno") {
        add(&mut a, &["--js-runtimes", &format!("deno:{}", deno.display())]);
    }
    a
}

/// The browser name to hand to `--cookies-from-browser`. Only these three are offered; anything else is ignored.
pub fn browser_arg(b: Option<&str>) -> Option<&'static str> {
    match b {
        Some("chrome") => Some("chrome"),
        Some("edge") => Some("edge"),
        Some("firefox") => Some("firefox"),
        _ => None,
    }
}

/// Sites that recently answered "too many requests", and when. SARAB uses it to stop adding requests to a site
/// that is currently refusing it (that only prolongs the block).
static LIMITED: Mutex<Option<HashMap<String, Instant>>> = Mutex::new(None);

/// "https://www.youtube.com/watch?v=x" and "https://youtu.be/x" are the same site: "youtube.com".
pub fn site_of(url: &str) -> Option<String> {
    let host = url::Url::parse(url).ok()?.host_str()?.to_lowercase();
    let host = host.trim_start_matches("www.").trim_start_matches("m.").to_string();
    Some(if host == "youtu.be" || host.ends_with("youtube-nocookie.com") { "youtube.com".to_string() } else { host })
}

/// Remember that this link's site is refusing us right now.
pub fn note_rate_limited(url: &str) {
    if let Some(site) = site_of(url) {
        LIMITED.lock().unwrap().get_or_insert_with(HashMap::new).insert(site, Instant::now());
    }
}

/// Forget it: something just worked.
pub fn clear_rate_limit(url: &str) {
    if let Some(site) = site_of(url) {
        if let Some(map) = LIMITED.lock().unwrap().as_mut() {
            map.remove(&site);
        }
    }
}

/// Did this link's site refuse us less than `within` ago?
pub fn recently_rate_limited(url: &str, within: Duration) -> bool {
    let Some(site) = site_of(url) else { return false };
    let hit = LIMITED.lock().unwrap().as_ref().and_then(|m| m.get(&site)).map_or(false, |t| t.elapsed() < within);
    hit
}

pub async fn probe(app: &AppHandle, url: &str) -> Result<MediaInfo, String> {
    // The site just refused us with "too many requests": don't poke it again just to draw a preview.
    if recently_rate_limited(url, Duration::from_secs(600)) {
        return Err("ratelimit".into());
    }
    let result = probe_with_cookies(app, url).await;
    match &result {
        Err(code) if code == "ratelimit" => note_rate_limited(url),
        Ok(_) => clear_rate_limit(url),
        _ => {}
    }
    result
}

async fn probe_with_cookies(app: &AppHandle, url: &str) -> Result<MediaInfo, String> {
    let s = settings::current(app);
    let browser = browser_arg(s.cookies_browser.as_deref());
    match probe_once(app, url, browser).await {
        // yt-dlp could not read the browser's cookies. A public video does not need them, so look again without.
        Err(code) if browser.is_some() && code == "browser_cookies" => match probe_once(app, url, None).await {
            // The video DOES need a sign-in, so the cookie problem is the useful thing to tell the user.
            Err(c) if c == "signin" => Err(code),
            other => other,
        },
        other => other,
    }
}

async fn probe_once(app: &AppHandle, url: &str, browser: Option<&str>) -> Result<MediaInfo, String> {
    let s = settings::current(app);
    let mut cmd = binaries::command(&binaries::resolve(app, "yt-dlp"));
    cmd.args(["-J", "--no-playlist", "--flat-playlist", "--no-warnings"]).args(engine_args(app));
    if let Some(b) = browser {
        cmd.args(["--cookies-from-browser", b]);
    } else if s.use_cookies {
        if let Some(c) = s.cookies_file.as_deref().filter(|c| std::path::Path::new(c).exists()) {
            cmd.args(["--cookies", c]);
        }
    }
    let started = std::time::Instant::now();
    let out = cmd
        .arg("--")
        .arg(url)
        .stdin(Stdio::null())
        .output()
        .await
        .map_err(|_| "probe_engine".to_string())?;
    // Console only (visible in the `npm run tauri dev` terminal): how long the link preview's lookup took.
    eprintln!("[sarab] preview lookup took {:.1} s", started.elapsed().as_secs_f64());

    if !out.status.success() {
        let lines: Vec<String> = String::from_utf8_lossy(&out.stderr).lines().map(String::from).collect();
        return Err(explain(&lines).0);
    }
    let v: serde_json::Value = serde_json::from_slice(&out.stdout).map_err(|_| "probe_parse".to_string())?;

    let mut heights: Vec<u32> = v["formats"]
        .as_array()
        .map(|fs| {
            fs.iter()
                .filter(|f| f["vcodec"].as_str().map_or(false, |c| c != "none"))
                .filter_map(|f| f["height"].as_u64())
                .map(|h| h as u32)
                .collect()
        })
        .unwrap_or_default();
    heights.sort_unstable_by(|a, b| b.cmp(a));
    heights.dedup();

    let platform = v["webpage_url_domain"]
        .as_str()
        .or_else(|| v["extractor_key"].as_str())
        .map(String::from);

    Ok(MediaInfo {
        title: v["title"].as_str().unwrap_or("Untitled").to_string(),
        thumbnail: v["thumbnail"].as_str().map(String::from),
        duration: v["duration"].as_f64(),
        uploader: v["uploader"].as_str().map(String::from),
        platform,
        heights,
    })
}

/// Returns (args, number of streams yt-dlp will fetch per video). The latter lets the UI show one smooth bar.
/// `name` overrides the output file name (without extension). It is only used when saving a second copy
/// of a file that already exists (see `execute` in queue.rs); normally it is None and the usual template applies.
pub fn download_args(app: &AppHandle, req: &DownloadRequest, name: Option<&str>) -> (Vec<String>, usize) {
    let mut a: Vec<String> = Vec::new();
    add(&mut a, &["--newline", "--no-colors", "--no-simulate", "--progress", "--concurrent-fragments", "4"]);
    add(&mut a, &[if req.single_video { "--no-playlist" } else { "--yes-playlist" }]);
    // Machine-readable lines our parser in queue.rs picks up.
    add(&mut a, &["--print", "before_dl:SARAB_INFO|%(id)s|%(thumbnail)s|%(title)s"]);
    add(&mut a, &["--print", "after_move:SARAB_FILE|%(id)s|%(filepath)s"]);
    add(
        &mut a,
        &["--progress-template", "download:SARAB_PROGRESS|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s"],
    );
    let template = match name {
        Some(n) => format!("{n}.%(ext)s"),
        None => "%(title).150B [%(id)s].%(ext)s".to_string(),
    };
    add(&mut a, &["-P", &req.dir, "-o", &template]);
    a.extend(engine_args(app));

    // Cookies are optional. A browser the user picked wins over a cookies file; a file is only passed if it is
    // really there, so a missing one never blocks a download.
    if let Some(b) = browser_arg(req.cookies_browser.as_deref()) {
        add(&mut a, &["--cookies-from-browser", b]);
    } else if let Some(c) = req.cookies_file.as_deref().filter(|c| std::path::Path::new(c).exists()) {
        add(&mut a, &["--cookies", c]);
    }

    // Optional clip. Only added when the user typed a start and/or end time (validated in queue::clean_trim),
    // so a normal download is exactly the same command as before. Cutting at the exact times makes ffmpeg
    // re-encode around the cut points: a little slower, but frame-accurate.
    if req.trim_start.is_some() || req.trim_end.is_some() {
        let from = req.trim_start.as_deref().unwrap_or("0");
        let to = req.trim_end.as_deref().unwrap_or("inf");
        add(&mut a, &["--download-sections", &format!("*{from}-{to}"), "--force-keyframes-at-cuts"]);
    }

    let streams = match req.format.as_str() {
        "mp3" => {
            add(&mut a, &["-f", "ba/b", "-x", "--audio-format", "mp3", "--audio-quality", "0"]);
            add(&mut a, &["--embed-thumbnail", "--convert-thumbnails", "jpg", "--embed-metadata"]);
            1
        }
        "audio" => {
            add(&mut a, &["-f", "ba[ext=m4a]/ba/b", "-x", "--audio-format", "m4a"]);
            add(&mut a, &["--embed-thumbnail", "--convert-thumbnails", "jpg", "--embed-metadata"]);
            1
        }
        _ => {
            // MP4: prefer the requested resolution, then H.264/AAC for compatibility.
            let sort = match req.quality.parse::<u32>() {
                Ok(h) => format!("res:{h},vcodec:h264,acodec:m4a"),
                Err(_) => "res,vcodec:h264,acodec:m4a".to_string(),
            };
            // "bv+ba" = a video-only stream plus an audio-only stream. NOT "bv*", which also accepts the old
            // combined files (YouTube's itag 22 is the only HD one, so 720p used to pick it) and those often answer
            // 403 Forbidden. "/b" is the fallback for sites that only offer combined files (TikTok, Instagram...).
            add(&mut a, &["-f", "bv+ba/b", "-S", &sort, "--merge-output-format", "mp4"]);
            if req.convert_mp4 {
                // yt-dlp only re-encodes when the result isn't already MP4.
                add(&mut a, &["--recode-video", "mp4"]);
            }
            2
        }
    };
    add(&mut a, &["--", &req.url]);
    (a, streams)
}

/// yt-dlp's own reason for failing: the last line it printed that starts with "ERROR". Warnings never count.
pub fn error_line(lines: &[String]) -> Option<String> {
    lines.iter().rev().find(|l| l.trim_start().starts_with("ERROR")).map(|l| l.trim().to_string())
}

/// True only when yt-dlp itself says the site wants you signed in (age check, members-only, bot check...).
/// A bare "sign in" or "cookies" is deliberately NOT enough: those words turn up in harmless warnings and in
/// errors that have nothing to do with logging in.
fn needs_sign_in(lower: &str) -> bool {
    let l = lower.replace('\u{2019}', "'"); // curly apostrophe -> straight, so "you’re" matches "you're"
    [
        "sign in to confirm", // "Sign in to confirm you're not a bot" / "...your age"
        "not a bot",
        "confirm your age",
        "age-restricted",
        "age restricted",
        "login required",
        "requires login",
        "requires authentication",
        "authentication required",
        "please sign in",
        "please log in",
        "need to log in",
        "--cookies", // yt-dlp's own hint: "Use --cookies-from-browser or --cookies for the authentication"
        "members-only",
        "members only",
        "join this channel",
        "http error 401",
    ]
    .iter()
    .any(|n| l.contains(n))
}

/// True when yt-dlp says it could not read a browser's cookie store: the browser is open and has the file
/// locked, newer Chrome/Edge encryption it cannot open, or the file is not readable. `lower` is the lowercased
/// ERROR line.
fn browser_cookie_trouble(lower: &str) -> bool {
    const SPECIFIC: [&str; 5] = ["cookie database", "cookies database", "failed to decrypt", "dpapi", "database is locked"];
    const WITH_COOKIE: [&str; 7] = ["could not copy", "could not find", "permission denied", "unable to read", "failed to read", "failed to load", "cannot read"];
    SPECIFIC.iter().any(|n| lower.contains(n)) || (lower.contains("cookie") && WITH_COOKIE.iter().any(|n| lower.contains(n)))
}

/// Turn what yt-dlp reported into a short code. The UI translates it (see `err.*` in src/i18n/dict.ts).
/// `error_line` is yt-dlp's last "ERROR:" line, if it printed one; `tail` is the last non-warning output, used
/// only when there was no ERROR line. Only an ERROR line may say that a sign-in is required.
pub fn friendly_error(error_line: Option<&str>, tail: &str) -> String {
    let l = error_line.unwrap_or(tail).to_lowercase();
    let has = |needles: &[&str]| needles.iter().any(|n| l.contains(n));
    let code = if has(&["not available in your country", "geo restrict", "geo-restrict", "blocked it in your country"]) {
        "geo"
    } else if has(&["private video"]) {
        "private"
    } else if error_line.is_some() && browser_cookie_trouble(&l) {
        "browser_cookies"
    } else if error_line.is_some() && needs_sign_in(&l) {
        "signin"
    } else if has(&["video unavailable", "has been removed", "no longer available", "does not exist", "http error 404"]) {
        "unavailable"
    } else if has(&["unsupported url"]) {
        "unsupported"
    } else if has(&["http error 429", "too many requests"]) {
        "ratelimit"
    } else if has(&["unable to download webpage", "getaddrinfo", "timed out", "connection reset", "network is unreachable"]) {
        "network"
    } else if has(&["ffmpeg", "ffprobe"]) && has(&["not found", "not installed"]) {
        "ffmpeg"
    } else if has(&["no space left", "disk full"]) {
        "disk"
    } else {
        "generic"
    };
    code.into()
}

/// Classify a failed run. Returns the error code plus, for the cases our own message cannot fully explain (a
/// sign-in request, or a vague failure), yt-dlp's original wording so it can be shown as-is.
pub fn explain(lines: &[String]) -> (String, Option<String>) {
    let error = error_line(lines);
    let quiet: Vec<&String> = lines.iter().filter(|l| !l.trim_start().starts_with("WARNING")).collect();
    let tail = quiet[quiet.len().saturating_sub(6)..].iter().map(|s| s.as_str()).collect::<Vec<_>>().join("\n");
    let mut code = friendly_error(error.as_deref(), &tail);
    // YouTube refused even the page request with HTTP 429 (a WARNING) and the final ERROR is only the bot check that
    // follows from it. The real cause is the rate limit, and cookies cannot clear that, so don't send the user
    // off to fix cookies.
    if code == "signin" && lines.iter().any(|l| l.to_lowercase().contains("http error 429")) {
        code = "ratelimit".into();
    }
    let detail = if code == "signin" || code == "generic" || code == "browser_cookies" { error.map(|e| short_reason(&e)) } else { None };
    (code, detail)
}

/// The short reason to show under the message: yt-dlp's wording without the "ERROR:" and "[site] video-id:"
/// prefixes, cut after the first sentence (the rest is links and advice). The full text stays in Details (Logs).
fn short_reason(e: &str) -> String {
    let mut s = e.trim().trim_start_matches("ERROR:").trim();
    if s.starts_with('[') {
        if let Some(i) = s.find(']') {
            if let Some((id, tail)) = s[i + 1..].trim_start().split_once(": ") {
                if !id.contains(' ') {
                    s = tail.trim(); // only a real video id (no spaces); "Unable to download webpage: ..." stays whole
                }
            }
        }
    }
    let end = [". ", " See ", " Use "].iter().filter_map(|m| s.find(m)).min().unwrap_or(s.len());
    s[..end].trim_end_matches('.').chars().take(120).collect()
}

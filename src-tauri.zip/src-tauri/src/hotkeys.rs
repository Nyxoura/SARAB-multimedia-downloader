//! System-wide shortcuts. They fire even when SARAB is minimised, hidden or unfocused.

use crate::clipboard;
use std::sync::Mutex;
use tauri::{AppHandle, Manager};
use tauri_plugin_global_shortcut::{GlobalShortcutExt, Shortcut};

/// Ids of the two registered shortcuts: (download from clipboard, show/hide window).
pub struct HotkeyIds(pub Mutex<(u32, u32)>);

/// Replace the registered shortcuts. On failure nothing is left half-registered and an
/// error code is returned (`hotkey_invalid`, `hotkey_conflict`, `hotkey_in_use`).
pub fn apply(app: &AppHandle, download: &str, toggle: &str) -> Result<(), String> {
    let a: Shortcut = download.parse().map_err(|_| "hotkey_invalid".to_string())?;
    let b: Shortcut = toggle.parse().map_err(|_| "hotkey_invalid".to_string())?;
    if a.id() == b.id() {
        return Err("hotkey_conflict".into());
    }
    let gs = app.global_shortcut();
    let _ = gs.unregister_all();
    if gs.register(a.clone()).is_err() {
        return Err("hotkey_in_use".into());
    }
    if gs.register(b.clone()).is_err() {
        let _ = gs.unregister(a);
        return Err("hotkey_in_use".into());
    }
    *app.state::<HotkeyIds>().0.lock().unwrap() = (a.id(), b.id());
    Ok(())
}

/// Called by the plugin's handler on key press.
pub fn on_press(app: &AppHandle, id: u32) {
    let (download, toggle) = *app.state::<HotkeyIds>().0.lock().unwrap();
    if id == download {
        clipboard::download_from_clipboard(app);
    } else if id == toggle {
        toggle_window(app);
    }
}

pub fn toggle_window(app: &AppHandle) {
    let Some(w) = app.get_webview_window("main") else { return };
    let visible = w.is_visible().unwrap_or(false);
    let minimized = w.is_minimized().unwrap_or(false);
    let focused = w.is_focused().unwrap_or(false);
    if visible && !minimized && focused {
        let _ = w.hide();
    } else {
        let _ = w.unminimize();
        let _ = w.show();
        let _ = w.set_focus();
    }
}

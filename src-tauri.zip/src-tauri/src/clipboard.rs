//! Clipboard link detection and the "download from clipboard" action.

use crate::{
    notify,
    queue::{self, Queue},
    settings,
};
use serde::Serialize;
use std::{
    sync::Arc,
    time::{Duration, Instant},
};
use tauri::{AppHandle, Emitter, Manager};
use tauri_plugin_clipboard_manager::ClipboardExt;

/// Sites whose links the watcher reacts to on its own. (The hotkey accepts any http(s) link.)
const SITES: &[&str] = &[
    "youtube.com", "youtu.be", "twitter.com", "x.com", "tiktok.com", "instagram.com", "facebook.com",
    "fb.watch", "vimeo.com", "soundcloud.com", "twitch.tv", "dailymotion.com", "reddit.com", "redd.it",
    "bilibili.com", "b23.tv", "pinterest.com", "pin.it", "snapchat.com", "threads.net", "streamable.com",
    "rumble.com", "kick.com", "bsky.app", "vk.com", "ok.ru",
];

/// Every distinct http(s) link in the text, in order.
pub fn extract_links(text: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for w in text.split_whitespace() {
        let lower = w.to_lowercase();
        let looks_like_url = lower.starts_with("http://") || lower.starts_with("https://");
        if looks_like_url && url::Url::parse(w).is_ok() && !out.iter().any(|x| x == w) {
            out.push(w.to_string());
        }
    }
    out
}

/// True for a single link to a known media site.
fn is_media_url(s: &str) -> bool {
    let t = s.trim();
    if t.is_empty() || t.contains(char::is_whitespace) {
        return false;
    }
    let Ok(u) = url::Url::parse(t) else { return false };
    if !matches!(u.scheme(), "http" | "https") {
        return false;
    }
    let Some(host) = u.host_str() else { return false };
    let host = host.to_lowercase();
    SITES.iter().any(|d| host == *d || host.ends_with(&format!(".{d}")))
}

#[derive(Serialize, Clone)]
struct Notice {
    code: String,
    count: Option<usize>,
}

/// Small in-app message (the UI shows it as a toast, translated by `notice.<code>`).
fn notice(app: &AppHandle, code: &str, count: Option<usize>) {
    let _ = app.emit("app://notice", Notice { code: code.into(), count });
}

/// Windows numbers every clipboard change, and the number moves on EVERY copy, even when the copied text is
/// identical to what was there. That is how a link copied a second time is told apart from "nothing happened".
#[cfg(windows)]
fn clipboard_seq() -> Option<u32> {
    #[link(name = "user32")]
    extern "system" {
        fn GetClipboardSequenceNumber() -> u32;
    }
    // SAFETY: a plain Win32 call that takes no arguments and no pointers.
    Some(unsafe { GetClipboardSequenceNumber() })
}

/// Other systems: no such counter here, so only a different text counts as a new copy.
#[cfg(not(windows))]
fn clipboard_seq() -> Option<u32> {
    None
}

/// Polls the clipboard. Polling (instead of a change event) keeps it portable and it keeps
/// working while the window is hidden. Whatever is on the clipboard at launch is ignored.
pub fn start_watcher(app: AppHandle) {
    tauri::async_runtime::spawn(async move {
        let mut last_text = app.clipboard().read_text().ok();
        let mut last_seq = clipboard_seq();
        // The link we last acted on and when, to ignore a program that keeps re-writing the same clipboard.
        let mut last_url: Option<(String, Instant)> = None;
        loop {
            tokio::time::sleep(Duration::from_millis(800)).await;

            // A copy happened if the clipboard's change counter moved (Windows: even for identical text),
            // or, where there is no counter, if the text itself is different.
            let seq = clipboard_seq();
            let copied = matches!((seq, last_seq), (Some(a), Some(b)) if a != b);
            last_seq = seq;

            let Ok(text) = app.clipboard().read_text() else { continue };
            let changed = last_text.as_deref() != Some(text.as_str());
            if !copied && !changed {
                continue;
            }
            last_text = Some(text.clone());

            let s = settings::current(&app);
            if !s.detect_clipboard || !is_media_url(&text) {
                continue;
            }
            let url = text.trim().to_string();

            // The same link twice within a moment is not a person copying it again.
            if let Some((prev, at)) = &last_url {
                if *prev == url && at.elapsed() < Duration::from_millis(1500) {
                    continue;
                }
            }
            last_url = Some((url.clone(), Instant::now()));

            if s.auto_start && s.download_dir.is_some() {
                let q = app.state::<Arc<Queue>>();
                if let Ok(n) = queue::enqueue(&app, &q, vec![url], None, None) {
                    notice(&app, "queued", Some(n));
                }
            } else {
                // Not auto-starting: just drop the link into the input bar.
                let _ = app.emit("clipboard://url", url);
            }
        }
    });
}

/// The "Download from clipboard" hotkey.
pub fn download_from_clipboard(app: &AppHandle) {
    let text = app.clipboard().read_text().unwrap_or_default();
    let links = extract_links(&text);
    let unfocused = !notify::window_focused(app);

    if links.is_empty() {
        notice(app, "no_link", None);
        if unfocused {
            notify::show(
                app,
                ("No link found", "Copy a video link first, then try again."),
                ("لا يوجد رابط", "انسخ رابط فيديو أولًا ثم حاول مرة أخرى."),
            );
        }
        return;
    }
    let q = app.state::<Arc<Queue>>();
    match queue::enqueue(app, &q, links, None, None) {
        Ok(n) => {
            notice(app, "queued", Some(n));
            if unfocused {
                notify::show(
                    app,
                    ("Download started", "Added to the queue."),
                    ("بدأ التحميل", "تمت الإضافة إلى قائمة التحميل."),
                );
            }
        }
        Err(code) => notice(app, &code, None),
    }
}

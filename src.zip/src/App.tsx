import { useEffect, useRef, useState, type CSSProperties } from "react";
import { listen } from "@tauri-apps/api/event";
import { AnimatePresence, motion } from "framer-motion";
import { api, type DownloadRequest, type Notice, type Update } from "./lib/api";
import { persist } from "./lib/actions";
import { probeCache } from "./lib/probeCache";
import { chime } from "./lib/sound";
import { isRtl, tr, useLang, useT } from "./i18n";
import { useStore, type Tab } from "./store";
import TopBar from "./components/TopBar";
import DownloadTab from "./components/DownloadTab";
import HistoryTab from "./components/HistoryTab";
import SettingsTab from "./components/SettingsTab";
import StatusBar from "./components/StatusBar";
import FaqModal from "./components/FaqModal";
import Onboarding from "./components/Onboarding";
import Splash from "./components/Splash";
import Toasts from "./components/Toasts";

let booted = false; // StrictMode runs effects twice in dev; the boot work must run once.
const TABS: Tab[] = ["download", "history", "settings"];

export default function App() {
  const t = useT();
  const lang = useLang();
  const { settings, setSettings, setHistory, tab, setTab, faqOpen, applyUpdate, appendLog, addTask } = useStore();
  const [splash, setSplash] = useState(true); // plays once per launch
  const [engine, setEngine] = useState<{ ready: boolean }>({ ready: true });
  // Motion phases: hidden behind the splash, then the intro (header, tabs, content slide in), then idle.
  const [intro, setIntro] = useState(false);
  const [flip, setFlip] = useState(false); // plays when the language changes
  const prevLang = useRef(lang);

  useEffect(() => {
    if (splash) return;
    setIntro(true);
    const id = setTimeout(() => setIntro(false), 1500);
    return () => clearTimeout(id);
  }, [splash]);

  useEffect(() => {
    if (prevLang.current === lang) return;
    prevLang.current = lang;
    setFlip(true);
    const id = setTimeout(() => setFlip(false), 560);
    return () => clearTimeout(id);
  }, [lang]);

  // Boot: load settings and history, make sure yt-dlp / ffmpeg exist.
  useEffect(() => {
    if (booted) return;
    booted = true;
    (async () => {
      const s = await api.getSettings();
      setSettings(s);
      api.getHistory().then(setHistory).catch(() => {});

      // The download engine (yt-dlp, ffmpeg, deno) ships inside the app, so there is nothing to download.
      // If it is missing the installation is damaged: say so instead of trying to fetch it.
      const st = await api.checkBinaries();
      if (!st.ytdlp || !st.ffmpeg) setEngine({ ready: false });
    })();
  }, [setSettings, setHistory]);

  // Backend events.
  useEffect(() => {
    const subs = [
      // A download was queued (from the button, the hotkey or the clipboard watcher).
      listen<DownloadRequest>("download://added", (e) => {
        const req = e.payload;
        const info = probeCache.get(req.url);
        addTask({
          id: req.id, url: req.url, req, status: "queued", percent: 0, logs: [],
          title: info?.title, thumbnail: info?.thumbnail ?? undefined,
        });
      }),
      listen<Update>("download://update", (e) => {
        applyUpdate(e.payload);
        if (e.payload.status !== "done") return;
        const st = useStore.getState();
        const title = e.payload.title ?? st.tasks.find((x) => x.id === e.payload.id)?.title;
        st.pushToast({
          id: e.payload.id,
          text: title ? tr("toast.saved", { title }) : tr("toast.savedPlain"),
          path: e.payload.filePath ?? undefined,
        });
        if (st.settings?.notifyOnDone) chime();
        api.getHistory().then(st.setHistory).catch(() => {});
      }),
      listen<{ id: string; line: string }>("download://log", (e) => appendLog(e.payload.id, e.payload.line)),
      // Auto-start is off: a copied link is placed in the link box instead of downloading.
      listen<string>("clipboard://url", (e) => {
        const { draft, setDraft } = useStore.getState();
        if (!draft.includes(e.payload)) setDraft(draft.trim() ? `${draft.trim()}\n${e.payload}` : e.payload);
        useStore.getState().setTab("download");
      }),
      listen<Notice>("app://notice", (e) => {
        useStore.getState().pushToast({ id: "notice", text: tr(`notice.${e.payload.code}`, { n: e.payload.count ?? 0 }) });
      }),
    ];
    return () => subs.forEach((p) => p.then((un) => un()));
  }, [applyUpdate, appendLog, addTask]);

  // Theme, language and direction.
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = settings?.theme ?? "dark";
    root.lang = lang;
    root.dir = isRtl(lang) ? "rtl" : "ltr";
    document.title = lang === "ar" ? "سراب — SARAB" : "SARAB — سراب";
  }, [settings?.theme, lang]);

  const z = (settings?.uiScale ?? 100) / 100;

  // The splash sits outside the zoomed .app wrapper and is always rendered, even while settings
  // are still loading, so it starts instantly and its animation is never restarted.
  return (
    <>
      {settings && (
        <div className={"app" + (splash ? " pre" : intro ? " intro" : "") + (flip ? " flip" : "")} style={{ zoom: z, "--z": z } as CSSProperties}>
          <TopBar />

          <nav className="tabs" role="tablist">
            <div className="tabs-in" style={{ "--i": TABS.indexOf(tab) } as CSSProperties}>
              <span className="tab-ind" aria-hidden="true" />
              {TABS.map((id) => (
                <button key={id} role="tab" aria-selected={tab === id} className={"tab" + (tab === id ? " on" : "")} onClick={() => setTab(id)}>
                  {t(`nav.${id}`)}
                </button>
              ))}
            </div>
          </nav>

          <main className="content">
            {!engine.ready && (
              <div className="banner" role="alert">
                {t("engine.missing")}
              </div>
            )}

            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={tab}
                className="pane"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.16, ease: "easeOut" }}
              >
                {tab === "download" && <DownloadTab blocked={!settings.downloadDir || !engine.ready} />}
                {tab === "history" && <HistoryTab />}
                {tab === "settings" && <SettingsTab />}
              </motion.div>
            </AnimatePresence>
          </main>

          {tab === "download" && <StatusBar />}

          <Toasts />
          <AnimatePresence>{faqOpen && <FaqModal key="faq" />}</AnimatePresence>
          <Onboarding />
        </div>
      )}

      <AnimatePresence>
        {splash && <Splash key="splash" onDone={() => setSplash(false)} />}
      </AnimatePresence>
    </>
  );
}

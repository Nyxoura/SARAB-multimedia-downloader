import type { MediaInfo } from "./api";

/** Link previews already fetched, so a queued row can show its title before its turn comes. */
export const probeCache = new Map<string, MediaInfo>();

import { en } from "../i18n/dict";
import { tr } from "../i18n";

/** Backend errors are short codes ("geo", "no_folder"); show them in the user's language. */
export function errText(e: unknown): string {
  const raw = String(e).replace(/^Error:\s*/, "");
  return `err.${raw}` in en ? tr(`err.${raw}`) : raw;
}

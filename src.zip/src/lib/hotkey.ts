/**
 * Hotkeys are stored the way the backend parses them: "Shift+A", "Alt+BracketLeft".
 * This file turns key events into that format and into friendly text for display.
 */

export const DEFAULT_HOTKEYS = { download: "Shift+A", toggle: "Alt+BracketLeft" } as const;

const SYMBOLS: Record<string, string> = {
  BracketLeft: "[", BracketRight: "]", Backquote: "`", Minus: "-", Equal: "=", Semicolon: ";",
  Quote: "'", Comma: ",", Period: ".", Slash: "/", Backslash: "\\", Space: "Space",
  ArrowUp: "↑", ArrowDown: "↓", ArrowLeft: "←", ArrowRight: "→",
};

/** "Alt+BracketLeft" becomes "Alt + [". */
export function fmtHotkey(combo: string): string {
  return combo.split("+").map((p) => SYMBOLS[p] ?? p).join(" + ");
}

/** Returns the combo, "NEEDMOD" if no modifier was held, or null while only a modifier is down. */
export function eventToHotkey(e: KeyboardEvent): string | null {
  if (/^(Control|Alt|Shift|Meta|OS)(Left|Right)?$/.test(e.code)) return null;
  const mods: string[] = [];
  if (e.ctrlKey) mods.push("Ctrl");
  if (e.altKey) mods.push("Alt");
  if (e.shiftKey) mods.push("Shift");
  if (e.metaKey) mods.push("Super");
  if (!mods.length) return "NEEDMOD";
  const c = e.code;
  const key = c.startsWith("Key") ? c.slice(3) : c.startsWith("Digit") ? c.slice(5) : c;
  return [...mods, key].join("+");
}

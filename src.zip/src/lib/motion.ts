/** Resolves after `ms` milliseconds. Used to let an exit animation finish before the item is really removed. */
export const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** How long a list row takes to collapse when it is removed. Keep in sync with `.row.leaving` in styles.css. */
export const LEAVE_MS = 320;

import type { Lang } from "./api";

export function fmtSpeed(bytesPerSec?: number): string {
  if (!bytesPerSec) return "";
  const units = ["B", "KB", "MB", "GB"];
  let v = bytesPerSec, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v >= 100 ? 0 : 1)} ${units[i]}/s`;
}

export function fmtDuration(totalSeconds?: number): string {
  if (totalSeconds == null) return "";
  const s = Math.round(totalSeconds);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`;
}

export const fmtEta = fmtDuration;

/** "C:\Users\me\Downloads\SARAB" becomes "Downloads / SARAB". */
export function shortPath(p: string): string {
  return p.split(/[\\/]/).filter(Boolean).slice(-2).join(" / ");
}

export const baseName = (p: string) => p.split(/[\\/]/).filter(Boolean).pop() ?? p;

export function fmtDate(ms: number, lang: Lang): string {
  try {
    return new Intl.DateTimeFormat(lang === "ar" ? "ar" : "en", { dateStyle: "medium", timeStyle: "short" }).format(new Date(ms));
  } catch {
    return new Date(ms).toLocaleString();
  }
}

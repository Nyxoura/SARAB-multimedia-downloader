import { api, type Settings } from "./api";
import { errText } from "./errors";
import { useStore } from "../store";

const fail = (e: unknown) => useStore.getState().pushToast({ id: "action-error", text: errText(e) });

export const notify = (text: string, id = "notice") => useStore.getState().pushToast({ id, text });

export const openFile = (path: string) => api.openFile(path).catch(fail);
export const showInFolder = (path: string) => api.showInFolder(path).catch(fail);
export const openFolder = (path: string) => api.openFile(path).catch(fail);
export const openUrl = (url: string) => api.openUrl(url).catch(fail);

/**
 * Apply a settings change: update the UI immediately, save through the backend, and roll back with a
 * message if the backend refuses (for example a hotkey another app already owns).
 */
export async function persist(patch: Partial<Settings>): Promise<boolean> {
  const { settings, setSettings } = useStore.getState();
  if (!settings) return false;
  setSettings({ ...settings, ...patch });
  try {
    await api.saveSettings({ ...settings, ...patch });
    return true;
  } catch (e) {
    setSettings(settings);
    fail(e);
    return false;
  }
}

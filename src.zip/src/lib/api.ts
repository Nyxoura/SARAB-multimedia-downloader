import { invoke } from "@tauri-apps/api/core";

export type Lang = "ar" | "en";
export type Theme = "dark" | "light";
export type Format = "mp4" | "mp3" | "audio";
export type CookieBrowser = "chrome" | "edge" | "firefox";
export type Quality = "best" | "2160" | "1080" | "720" | "480";
export type Status = "queued" | "downloading" | "done" | "error" | "cancelled";

export interface Settings {
  downloadDir: string | null;
  theme: Theme;
  /** null until first launch picks one from the system language */
  lang: Lang | null;
  format: Format;
  quality: Quality;
  useCookies: boolean;
  cookiesFile: string | null;
  /** Read cookies straight from this browser. Wins over the cookies file. */
  cookiesBrowser: CookieBrowser | null;
  singleVideo: boolean;
  convertMp4: boolean;
  detectClipboard: boolean;
  autoStart: boolean;
  notifyOnDone: boolean;
  launchOnStartup: boolean;
  hotkeyDownload: string;
  hotkeyToggle: string;
  uiScale: number;
}
export interface MediaInfo {
  title: string;
  thumbnail?: string | null;
  duration?: number | null;
  uploader?: string | null;
  platform?: string | null;
  heights: number[];
}
export interface BinStatus {
  ytdlp: boolean;
  ffmpeg: boolean;
  deno: boolean;
}
export interface DownloadRequest {
  id: string;
  url: string;
  format: Format;
  quality: Quality;
  dir: string;
  cookiesFile: string | null;
  cookiesBrowser?: string | null;
  singleVideo: boolean;
  convertMp4: boolean;
  /** Optional clip, as typed by the user ("1:30"). Absent = from the start / to the end. */
  trimStart?: string | null;
  trimEnd?: string | null;
}
export interface HistoryEntry {
  id: string;
  url: string;
  title: string;
  thumbnail?: string | null;
  format: Format;
  quality: Quality;
  filePath?: string | null;
  /** Unix time, milliseconds */
  finishedAt: number;
}
/** Payload of the `download://update` event. Null/absent fields mean "unchanged". `error` is a code (see err.* in the dictionary). */
export interface Update {
  id: string;
  status: Status;
  percent?: number | null;
  speed?: number | null;
  eta?: number | null;
  title?: string | null;
  thumbnail?: string | null;
  filePath?: string | null;
  error?: string | null;
  /** yt-dlp's own wording for a sign-in request or vague failure, shown under the message. */
  detail?: string | null;
}
export interface Notice {
  code: string;
  count?: number | null;
}

export const api = {
  getSettings: () => invoke<Settings>("get_settings"),
  saveSettings: (value: Settings) => invoke<void>("save_settings", { value }),
  checkBinaries: () => invoke<BinStatus>("check_binaries"),
  probe: (url: string) => invoke<MediaInfo>("probe_url", { url }),
  /** Queues the links in order, using the options currently saved in settings. `trim` clips a single link. */
  enqueue: (urls: string[], trim?: { start: string; end: string }) =>
    invoke<number>("enqueue_urls", { urls, trimStart: trim?.start ?? null, trimEnd: trim?.end ?? null }),
  retry: (req: DownloadRequest) => invoke<void>("start_download", { req }),
  cancel: (id: string) => invoke<void>("cancel_download", { id }),
  getHistory: () => invoke<HistoryEntry[]>("get_history"),
  removeHistory: (id: string) => invoke<void>("remove_history", { id }),
  clearHistory: () => invoke<void>("clear_history"),
  openFile: (path: string) => invoke<void>("open_file", { path }),
  showInFolder: (path: string) => invoke<void>("show_in_folder", { path }),
  openDataFolder: () => invoke<void>("open_data_folder"),
  openUrl: (url: string) => invoke<void>("open_url", { url }),
};

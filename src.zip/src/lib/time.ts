/** Parse "90", "1:30", "01:02:30" or "1:30.5" into seconds. Returns null if it isn't a valid time. */
export function parseTime(raw: string): number | null {
  const s = raw.trim();
  if (!/^\d+(:\d{1,2}){0,2}(\.\d+)?$/.test(s)) return null;
  const parts = s.split(":").map(Number);
  if (parts.slice(1).some((p) => p >= 60)) return null; // "1:75" is not a time
  return parts.reduce((total, p) => total * 60 + p, 0);
}

export type TrimIssue = "invalid" | "order" | null;

/** Check the optional clip boxes. Both empty is fine (no clip). Same rules as the backend. */
export function trimIssue(start: string, end: string): TrimIssue {
  const a = start.trim();
  const b = end.trim();
  if (!a && !b) return null;
  const from = a ? parseTime(a) : 0;
  const to = b ? parseTime(b) : Infinity;
  if (from === null || to === null) return "invalid";
  return to <= from ? "order" : null;
}

export const hasTrim = (start: string, end: string) => Boolean(start.trim() || end.trim());

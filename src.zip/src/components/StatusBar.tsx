import { fmtEta, fmtSpeed } from "../lib/format";
import { fmtHotkey } from "../lib/hotkey";
import { useT } from "../i18n";
import { useStore } from "../store";

/** Footer of the Download tab: progress of the running download, or the shortcut tip when idle. */
export default function StatusBar() {
  const t = useT();
  const tasks = useStore((s) => s.tasks);
  const settings = useStore((s) => s.settings)!;
  const active = tasks.find((x) => x.status === "downloading");
  const waiting = tasks.filter((x) => x.status === "queued").length;

  return (
    <footer className="statusbar">
      <div className="bar big" role="progressbar" aria-valuenow={Math.round(active?.percent ?? 0)} aria-valuemin={0} aria-valuemax={100}>
        <div
          className={"fill" + (active ? ((active.percent ?? 0) <= 0 ? " indet" : " live") : "")}
          style={{ width: `${active?.percent ?? 0}%` }}
        />
      </div>
      <div className="statusline small" key={active ? "busy" : waiting > 0 ? "wait" : "idle"}>
        {active ? (
          <>
            <span className="grow ellipsis" dir="auto">{t("status.busy", { title: active.title ?? active.url })}</span>
            <span dir="ltr">{Math.round(active.percent)}%</span>
            {active.speed ? <span dir="ltr">{fmtSpeed(active.speed)}</span> : null}
            {active.eta != null ? <span>{t("row.left", { t: fmtEta(active.eta) })}</span> : null}
            {waiting > 0 && <span className="muted">{t("status.waiting", { n: waiting })}</span>}
          </>
        ) : waiting > 0 ? (
          <span className="muted">{t("status.waiting", { n: waiting })}</span>
        ) : (
          <span className="muted">{t("status.ready", { key: fmtHotkey(settings.hotkeyDownload) })}</span>
        )}
      </div>
    </footer>
  );
}

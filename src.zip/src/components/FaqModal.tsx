import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { writeText } from "@tauri-apps/plugin-clipboard-manager";
import { notify, openUrl } from "../lib/actions";
import { fmtHotkey } from "../lib/hotkey";
import Collapse from "./Collapse";
import { useT, type Key } from "../i18n";
import { useStore } from "../store";

const MAKER = { name: "Nyxoura", guns: "guns.lol/nyxoura", discord: "x_p7" } as const;

const QA: { q: Key; a: Key }[] = [
  { q: "faq.q.sites", a: "faq.a.sites" },
  { q: "faq.q.multi", a: "faq.a.multi" },
  { q: "faq.q.clip", a: "faq.a.clip" },
  { q: "faq.q.cookies", a: "faq.a.cookies" },
  { q: "faq.q.files", a: "faq.a.files" },
  { q: "faq.q.privacy", a: "faq.a.privacy" },
];

export default function FaqModal() {
  const t = useT();
  const close = useStore((s) => s.setFaqOpen);
  const hotkey = useStore((s) => s.settings?.hotkeyDownload ?? "Shift+A");
  const [open, setOpen] = useState<Set<number>>(new Set());
  const toggle = (i: number) =>
    setOpen((s) => {
      const n = new Set(s);
      if (!n.delete(i)) n.add(i);
      return n;
    });

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [close]);

  async function copyDiscord() {
    try {
      await writeText(MAKER.discord);
      notify(t("toast.copied"), "copied");
    } catch {
      /* clipboard unavailable */
    }
  }

  return (
    <motion.div
      className="overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="faq-title"
      exit={{ opacity: 0, transition: { duration: 0.2 } }}
      onMouseDown={(e) => e.target === e.currentTarget && close(false)}
    >
      <motion.div className="modal glass faq" exit={{ opacity: 0, y: 14, scale: 0.97, transition: { duration: 0.18 } }}>
        <div className="faq-head">
          <div>
            <div className="wordmark">سراب</div>
            <h2 id="faq-title">{t("faq.title")}</h2>
          </div>
          <button className="btn sm" onClick={() => close(false)} aria-label={t("common.close")}>✕</button>
        </div>

        <p className="faq-about">{t("faq.about")}</p>

        <div className="qa">
          {QA.map(({ q, a }, i) => {
            const isOpen = open.has(i);
            return (
              <div className={"qa-item" + (isOpen ? " open" : "")} key={q}>
                <button className="qa-q" aria-expanded={isOpen} aria-controls={`qa-${i}`} onClick={() => toggle(i)}>
                  <span>{t(q)}</span>
                  <span className="chev" aria-hidden="true">▾</span>
                </button>
                <Collapse open={isOpen}>
                  <p id={`qa-${i}`}>{t(a, { key: fmtHotkey(hotkey) })}</p>
                </Collapse>
              </div>
            );
          })}
        </div>

        <div className="maker">
          <div className="maker-name">
            <span className="muted">{t("faq.maker")}</span> <strong dir="ltr">{MAKER.name}</strong>
          </div>
          <div className="maker-links">
            <div className="maker-line">
              <span className="muted small">{t("faq.guns")}</span>
              <button className="linkbtn" dir="ltr" onClick={() => openUrl(`https://${MAKER.guns}`)}>{MAKER.guns}</button>
            </div>
            <div className="maker-line">
              <span className="muted small">{t("faq.discord")}</span>
              <bdi className="mono" dir="ltr">{MAKER.discord}</bdi>
              <button className="btn sm" onClick={copyDiscord}>{t("faq.copy")}</button>
            </div>
          </div>
        </div>

      </motion.div>
    </motion.div>
  );
}

import { useEffect, useState } from "react";
import { open } from "@tauri-apps/plugin-dialog";
import { api } from "../lib/api";
import { notify, openUrl, persist } from "../lib/actions";
import { errText } from "../lib/errors";
import { baseName } from "../lib/format";
import { DEFAULT_HOTKEYS, eventToHotkey, fmtHotkey } from "../lib/hotkey";
import { useT } from "../i18n";
import { useStore } from "../store";
import Check from "./Check";

const SCALES = [90, 100, 110, 125];

function HotkeyRow({
  label, value, fallback, onChange,
}: { label: string; value: string; fallback: string; onChange: (combo: string) => void }) {
  const t = useT();
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    if (!capturing) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === "Escape") return setCapturing(false);
      const combo = eventToHotkey(e);
      if (combo === null) return; // only a modifier so far
      if (combo === "NEEDMOD") return notify(t("hk.needMod"), "hk");
      setCapturing(false);
      onChange(combo);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [capturing, onChange, t]);

  return (
    <div className="hkrow">
      <div className="hklabel">{label}</div>
      <div className="hkctl">
        <kbd className={"kbd" + (capturing ? " live" : "")}>{capturing ? t("hk.press") : fmtHotkey(value)}</kbd>
        <button className="btn sm" onClick={() => setCapturing((c) => !c)}>{t("hk.change")}</button>
        <button className="btn sm" disabled={value === fallback} onClick={() => { setCapturing(false); onChange(fallback); }}>
          {t("hk.reset")}
        </button>
      </div>
    </div>
  );
}

export default function SettingsTab() {
  const t = useT();
  const settings = useStore((s) => s.settings)!;

  async function browseCookies() {
    const file = await open({
      multiple: false,
      title: t("dialog.cookies"),
      filters: [{ name: "cookies.txt", extensions: ["txt"] }],
    });
    if (typeof file === "string") persist({ cookiesFile: file, useCookies: true });
  }

  return (
    <div className="grid">
      {/* 1. Automation */}
      <section className="card glass">
        <h3>{t("settings.automation")}</h3>
        <div className="stack">
          <Check checked={settings.detectClipboard} onChange={(v) => persist({ detectClipboard: v })}>{t("auto.detect")}</Check>
          <Check checked={settings.autoStart} onChange={(v) => persist({ autoStart: v })}>{t("auto.start")}</Check>
          <Check checked={settings.notifyOnDone} onChange={(v) => persist({ notifyOnDone: v })}>{t("auto.notify")}</Check>
          <Check checked={settings.launchOnStartup} onChange={(v) => persist({ launchOnStartup: v })}>{t("auto.startup")}</Check>
        </div>
      </section>

      {/* 2. Cookies file */}
      <section className="card glass">
        <h3>{t("settings.cookies")}</h3>
        <div className="saverow">
          <div className="path" title={settings.cookiesFile ?? ""}>
            {settings.cookiesFile ? baseName(settings.cookiesFile) : <span className="muted">{t("cookies.placeholder")}</span>}
          </div>
          <button className="btn" onClick={browseCookies}>{t("save.browse")}</button>
          <button
            className="btn"
            disabled={!settings.cookiesFile}
            onClick={() => persist({ cookiesFile: null, useCookies: false })}
          >
            {t("dl.clear")}
          </button>
        </div>
        <p className="note small muted">{t("cookies.hint")}</p>
      </section>

      {/* 3. Global hotkeys */}
      <section className="card glass">
        <h3>{t("settings.hotkeys")}</h3>
        <div className="stack">
          <HotkeyRow
            label={t("hk.download")}
            value={settings.hotkeyDownload}
            fallback={DEFAULT_HOTKEYS.download}
            onChange={(combo) => persist({ hotkeyDownload: combo })}
          />
          <HotkeyRow
            label={t("hk.toggle")}
            value={settings.hotkeyToggle}
            fallback={DEFAULT_HOTKEYS.toggle}
            onChange={(combo) => persist({ hotkeyToggle: combo })}
          />
        </div>
      </section>

      {/* 4. System & app */}
      <section className="card glass">
        <h3>{t("settings.system")}</h3>
        <div className="stack">
          <label className="field row-field">
            <span>{t("sys.scale")}</span>
            <select value={settings.uiScale} onChange={(e) => persist({ uiScale: Number(e.target.value) })}>
              {SCALES.map((n) => <option key={n} value={n}>{n}%</option>)}
            </select>
          </label>
          <div className="btnrow">
            <button className="btn" onClick={() => api.openDataFolder().catch((e) => notify(errText(e), "action-error"))}>
              {t("sys.dataFolder")}
            </button>
            <button className="btn" onClick={() => openUrl("https://discord.gg/BSGHWuTM5H")}>{t("sys.support")}</button>
          </div>
        </div>
      </section>
    </div>
  );
}

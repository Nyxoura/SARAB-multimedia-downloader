import { useState } from "react";
import { open } from "@tauri-apps/plugin-dialog";
import { downloadDir } from "@tauri-apps/api/path";
import { persist } from "../lib/actions";
import { useT } from "../i18n";
import { useStore } from "../store";

const LANGUAGE_CHOICE_KEY = "sarab-language-choice-complete";

/** The language picker is shown before any language is chosen, so it speaks both, whatever Windows is set to. */
const PICKER = {
  ar: { title: "اختر لغتك", body: "يمكنك تغييرها في أي وقت من الشريط العلوي." },
  en: { title: "Choose your language", body: "You can change it any time from the top bar." },
};

/** First-run dialog: nothing else is usable until a download folder is chosen. */
export default function Onboarding() {
  const t = useT();
  const settings = useStore((s) => s.settings);
  const [needsLanguageChoice, setNeedsLanguageChoice] = useState(
    () => localStorage.getItem(LANGUAGE_CHOICE_KEY) !== "yes",
  );

  if (!settings) return null;

  async function chooseLanguage(lang: "en" | "ar") {
    if (await persist({ lang })) {
      localStorage.setItem(LANGUAGE_CHOICE_KEY, "yes");
      setNeedsLanguageChoice(false);
    }
  }

  async function choose() {
    const dir = await open({
      directory: true,
      multiple: false,
      title: t("onboard.dialog"),
      defaultPath: await downloadDir().catch(() => undefined),
    });
    if (typeof dir === "string") persist({ downloadDir: dir });
  }

  if (needsLanguageChoice) {
    return (
      <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="ob-title">
        <div className="modal glass">
          <div className="wordmark big">سراب</div>
          <h2 id="ob-title">
            <span lang="ar" dir="rtl">{PICKER.ar.title}</span>
            <span aria-hidden="true"> · </span>
            <span lang="en" dir="ltr">{PICKER.en.title}</span>
          </h2>
          <p>
            <span className="bilingual-line" lang="ar" dir="rtl">{PICKER.ar.body}</span>
            <span className="bilingual-line" lang="en" dir="ltr">{PICKER.en.body}</span>
          </p>
          <div className="language-options">
            <button className="language-option" onClick={() => chooseLanguage("en")} autoFocus>
              {t("onboard.language.english")}
            </button>
            <button className="language-option" onClick={() => chooseLanguage("ar")}>
              {t("onboard.language.arabic")}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (settings.downloadDir) return null;

  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="ob-title">
      <div className="modal glass">
        <div className="wordmark big">سراب</div>
        <h2 id="ob-title">{t("onboard.title")}</h2>
        <p>{t("onboard.body")}</p>
        <button className="primary" onClick={choose} autoFocus>
          {t("onboard.pick")}
        </button>
      </div>
    </div>
  );
}

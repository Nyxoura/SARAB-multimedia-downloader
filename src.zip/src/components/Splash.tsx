import { useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";

/** One timeline for the letter and its glow: the S lands when the cracks reach it (about 0.55 s), holds, then fades. Total 2.2 s. */
const TIMELINE = { duration: 2.2, times: [0, 0.25, 0.75, 1], ease: "easeInOut" } as const;

type Crack = { d: string; delay: number; dur: number; w: number; o: number };

/** Small seeded random generator, so the glass breaks the same way on every launch. */
function seeded(seed: number) {
  let s = seed >>> 0;
  return () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296;
}

/**
 * Cracks that race in from the edges of the window toward the S: long main cracks, short branches,
 * and web rings that appear once the main cracks have passed them. Times are in seconds.
 */
function buildCracks(w: number, h: number): Crack[] {
  const rnd = seeded(5);
  const cx = w / 2, cy = h / 2;
  const rmax = Math.hypot(cx, cy) * 1.06;
  const N = 30;
  type Main = { ang: number; t0: number; dur: number; r0: number; r1: number };
  const mains: Main[] = [];
  const out: Crack[] = [];
  const path = (pts: [number, number][]) => "M" + pts.map((p) => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join("L");

  for (let i = 0; i < N; i++) {
    const ang = ((i + (rnd() - 0.5) * 0.7) / N) * Math.PI * 2;
    const r0 = rmax * (0.97 + rnd() * 0.06);
    const r1 = 75 + rnd() * 55;
    const pts: [number, number][] = [];
    let r = r0, a = ang;
    while (r > r1) {
      pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
      r -= 70 + rnd() * 110;
      a += (rnd() - 0.5) * 0.17;
    }
    pts.push([cx + r1 * Math.cos(a), cy + r1 * Math.sin(a)]);
    const t0 = rnd() * 0.09;
    const dur = 0.3 + rnd() * 0.14;
    mains.push({ ang, t0, dur, r0, r1 });
    out.push({ d: path(pts), delay: t0, dur, w: rnd() < 0.34 ? 2 : 1.2, o: 0.95 });

    for (let j = 1; j < pts.length - 1; j++) {
      if (rnd() > 0.6) continue;
      const [px, py] = pts[j];
      let a2 = Math.atan2(cy - py, cx - px) + (rnd() < 0.5 ? -1 : 1) * (0.4 + rnd() * 0.6);
      const len = 60 + rnd() * 140;
      const segs = 2 + Math.floor(rnd() * 2);
      const bp: [number, number][] = [[px, py]];
      for (let k = 0; k < segs; k++) {
        const step = (len / segs) * (0.7 + rnd() * 0.6);
        a2 += (rnd() - 0.5) * 1.1;
        const [lx, ly] = bp[bp.length - 1];
        bp.push([lx + step * Math.cos(a2), ly + step * Math.sin(a2)]);
      }
      out.push({ d: path(bp), delay: t0 + dur * (j / (pts.length - 1)) * 0.9, dur: 0.15 + rnd() * 0.12, w: 0.9, o: 0.75 });
    }
  }

  for (const rad of [170, 260, 380, 530, 720, 950, 1230]) {
    if (rad > rmax * 0.96) continue;
    for (let i = 0; i < N; i++) {
      if (rnd() > 0.82) continue;
      const A = mains[i], B = mains[(i + 1) % N];
      const angB = B.ang + (i === N - 1 ? Math.PI * 2 : 0);
      const pa: [number, number] = [cx + rad * Math.cos(A.ang), cy + rad * Math.sin(A.ang)];
      const pb: [number, number] = [cx + rad * Math.cos(angB), cy + rad * Math.sin(angB)];
      const am = (A.ang + angB) / 2;
      const rm = rad * (0.9 + rnd() * 0.16);
      const mid: [number, number] = [cx + rm * Math.cos(am), cy + rm * Math.sin(am)];
      const head = Math.max(...[A, B].map((c) => c.t0 + c.dur * Math.min(1, Math.max(0, (c.r0 - rad) / (c.r0 - c.r1)))));
      out.push({ d: path([pa, mid, pb]), delay: head + 0.01, dur: 0.14, w: 0.9, o: 0.65 });
    }
  }
  return out;
}

/** Splinters that burst outward from the S the moment the cracks arrive. */
function buildShards() {
  const rnd = seeded(9);
  return Array.from({ length: 18 }, () => {
    const a = rnd() * Math.PI * 2;
    const d = 240 + rnd() * 480;
    return { size: 16 + rnd() * 34, dx: Math.cos(a) * d, dy: Math.sin(a) * d, rot: rnd() * 360, spin: (rnd() - 0.5) * 420 };
  });
}

/**
 * Startup splash: glass cracks race in from the edges to the middle, hit the glowing "S" and burst into shards;
 * the S and its aura swell, hold, then everything fades out and `onDone` is called.
 * Render it inside <AnimatePresence> so the backdrop can fade away (see its `exit`) and reveal the app.
 */
export default function Splash({ onDone }: { onDone: () => void }) {
  const reduce = useReducedMotion(); // reduced motion: keep the fades, skip the cracks and scaling
  const [size] = useState(() => ({ w: window.innerWidth, h: window.innerHeight }));
  const cracks = useMemo(() => buildCracks(size.w, size.h), [size]);
  const shards = useMemo(buildShards, []);

  return (
    <motion.div
      className="splash"
      aria-hidden="true"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    >
      {!reduce && (
        <motion.svg
          className="splash-cracks"
          width={size.w}
          height={size.h}
          viewBox={`0 0 ${size.w} ${size.h}`}
          initial={{ opacity: 1 }}
          animate={{ opacity: [1, 1, 0] }}
          transition={{ duration: 2.2, times: [0, 0.45, 0.8], ease: "easeOut" }}
        >
          {cracks.map((c, i) => (
            <motion.path
              key={i}
              d={c.d}
              fill="none"
              stroke="#c9f4ff"
              strokeWidth={c.w}
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity={c.o}
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: c.delay, duration: c.dur, ease: [0.16, 1, 0.3, 1] }}
            />
          ))}
        </motion.svg>
      )}

      {/* wide, faint bloom: the light spreading out into the room */}
      <motion.div
        className="splash-halo outer"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.55, 0.55, 0], scale: reduce ? 1 : [0.35, 1, 1.35, 1.9] }}
        transition={TIMELINE}
      />
      {/* the aura right behind the letter: starts small and grows noticeably as the S grows */}
      <motion.div
        className="splash-halo"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.95, 0.95, 0], scale: reduce ? 1 : [0.4, 1, 1.25, 1.7] }}
        transition={TIMELINE}
      />

      {!reduce && (
        <>
          <motion.div
            className="splash-flash"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.9, 0], scale: [0.3, 1.1, 1.7] }}
            transition={{ delay: 0.46, duration: 0.6, times: [0, 0.2, 1], ease: "easeOut" }}
          />
          {shards.map((s, i) => (
            <motion.i
              key={i}
              className="splash-shard"
              style={{ width: s.size, height: s.size, marginLeft: -s.size / 2, marginTop: -s.size / 2 }}
              initial={{ opacity: 0 }}
              animate={{
                opacity: [0, 1, 0],
                x: [0, s.dx * 0.55, s.dx],
                y: [0, s.dy * 0.55, s.dy],
                rotate: [s.rot, s.rot + s.spin * 0.5, s.rot + s.spin],
                scale: [0.5, 1, 0.85],
              }}
              transition={{ delay: 0.5, duration: 1.1, times: [0, 0.12, 1], ease: [0.16, 1, 0.3, 1] }}
            />
          ))}
        </>
      )}

      <motion.span
        className="splash-s"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 1, 0], scale: reduce ? 1 : [0.6, 1, 1.04, 1.12] }}
        transition={TIMELINE}
        onAnimationComplete={onDone}
      >
        S
      </motion.span>
    </motion.div>
  );
}

import type { TrimIssue } from "../lib/time";
import { useT } from "../i18n";
import { useStore } from "../store";

/** Timestamp formats the boxes accept, shown as small chips. */
const EXAMPLES = ["45", "1:30", "1:02:30"];

/** Small "i" in a circle used by the note boxes. */
function InfoIcon() {
  return (
    <svg className="callout-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5" />
      <path d="M12 8h.01" />
    </svg>
  );
}

interface Props {
  /** How many links are in the box: a clip only makes sense for exactly one. */
  linkCount: number;
  /** Problem with the typed times, if any (the Download button is disabled while there is one). */
  issue: TrimIssue;
}

/**
 * "Trim a clip": optional start/end times, laid out as
 *   title, short description, [start] – [end], example chips, messages, and a separate note box.
 * Everything is flex/logical-property based, so it mirrors correctly in Arabic (RTL).
 */
export default function TrimPanel({ linkCount, issue }: Props) {
  const t = useT();
  const { trimStart, trimEnd, setTrim } = useStore();
  const several = linkCount > 1; // several links: no single clip applies

  return (
    <section className="adv-group trim-panel">
      <h3>{t("adv.trim")}</h3>
      <p className="trim-desc">{t("trim.desc")}</p>

      <div className="trim">
        <label className="field">
          <span className="muted small">{t("trim.start")}</span>
          <input
            className="time" dir="ltr" inputMode="decimal" spellCheck={false} disabled={several}
            value={trimStart} placeholder={t("trim.startPh")} onChange={(e) => setTrim(e.target.value, trimEnd)}
          />
        </label>
        <span className="trim-dash" aria-hidden="true">–</span>
        <label className="field">
          <span className="muted small">{t("trim.end")}</span>
          <input
            className="time" dir="ltr" inputMode="decimal" spellCheck={false} disabled={several}
            value={trimEnd} placeholder={t("trim.endPh")} onChange={(e) => setTrim(trimStart, e.target.value)}
          />
        </label>
      </div>

      <div className="trim-examples">
        <span>{t("trim.examples")}</span>
        {EXAMPLES.map((ex, i) => (
          <span className="trim-example" key={ex}>
            {i > 0 && <span className="dot" aria-hidden="true">•</span>}
            <code className="chip">{ex}</code>
          </span>
        ))}
      </div>

      {issue && <p className="hint bad" role="alert">{issue === "invalid" ? t("trim.invalid") : t("trim.order")}</p>}
      {several && <p className="hint">{t("trim.single")}</p>}

      <div className="callouts">
        <div className="callout warn" role="note">
          <InfoIcon />
          <span>{t("trim.note")}</span>
        </div>
        <div className="callout warn" role="note">
          <InfoIcon />
          <span>{t("trim.noteCookies")}</span>
        </div>
      </div>
    </section>
  );
}

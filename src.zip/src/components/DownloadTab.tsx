import { useEffect, useMemo, useState } from "react";
import { readText } from "@tauri-apps/plugin-clipboard-manager";
import { notify, persist } from "../lib/actions";
import { api, type MediaInfo } from "../lib/api";
import { errText } from "../lib/errors";
import { fmtDuration } from "../lib/format";
import { probeCache } from "../lib/probeCache";
import { hasTrim, trimIssue } from "../lib/time";
import { useT } from "../i18n";
import { useStore } from "../store";
import AdvancedOptions, { QUALITIES, isUnavailable } from "./AdvancedOptions";
import Collapse from "./Collapse";
import DownloadRow from "./DownloadRow";

export const parseLinks = (text: string) => [
  ...new Set(text.split(/\s+/).filter((s) => /^https?:\/\/\S+$/i.test(s))),
];

export default function DownloadTab({ blocked }: { blocked: boolean }) {
  const t = useT();
  const settings = useStore((s) => s.settings)!;
  const {
    draft, setDraft, tasks, clearFinished, logsOpen, setLogsOpen,
    advancedOpen, setAdvancedOpen, trimStart, trimEnd, setTrim,
  } = useStore();

  const [info, setInfo] = useState<MediaInfo | null>(null);
  const [probing, setProbing] = useState(false);
  const [probeError, setProbeError] = useState<string | null>(null);

  const links = useMemo(() => parseLinks(draft), [draft]);
  const key = links.join("\n");

  // Exactly one link: look it up for the preview, and grey out resolutions it doesn't have.
  useEffect(() => {
    setInfo(null);
    setProbeError(null);
    if (links.length !== 1 || blocked) return;
    // Already looked up (for example before switching tabs and back)? Reuse it instead of asking the site again.
    const cached = probeCache.get(links[0]);
    if (cached) {
      setInfo(cached);
      return;
    }
    let stale = false;
    setProbing(true);
    const timer = setTimeout(async () => {
      try {
        const i = await api.probe(links[0]);
        probeCache.set(links[0], i);
        if (!stale) setInfo(i);
      } catch (e) {
        if (!stale) setProbeError(errText(e));
      } finally {
        if (!stale) setProbing(false);
      }
    }, 600);
    return () => {
      stale = true;
      clearTimeout(timer);
      setProbing(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, blocked]);

  const maxHeight = info?.heights.length ? Math.max(...info.heights) : null;

  useEffect(() => {
    const q = QUALITIES.find((x) => x.id === settings.quality);
    if (q && isUnavailable(maxHeight, q.height)) persist({ quality: "best" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [maxHeight]);

  // A clip applies to one link only; with several links the clip boxes are ignored.
  const clipActive = links.length === 1 && hasTrim(trimStart, trimEnd);
  const issue = links.length === 1 ? trimIssue(trimStart, trimEnd) : null;
  const canDownload = !blocked && links.length > 0 && !issue;

  async function paste() {
    try {
      const text = await readText();
      if (text) setDraft(text);
    } catch {
      /* clipboard empty or not text */
    }
  }

  async function submit() {
    if (!canDownload || !settings.downloadDir) return;
    try {
      await api.enqueue(links, clipActive ? { start: trimStart, end: trimEnd } : undefined); // queued in box order
      setDraft("");
      setTrim("", "");
    } catch (e) {
      notify(errText(e), "enqueue-error");
    }
  }

  const active = tasks.find((x) => x.status === "downloading");
  const hasFinished = tasks.some((x) => x.status !== "queued" && x.status !== "downloading");
  // Logs of the running download, or of the most recent one that wrote any.
  const logTask = active ?? [...tasks].reverse().find((x) => x.logs.length > 0);

  // What the preview area shows. A new key remounts it, which replays its short fade-in.
  const previewState = info ? "card" : probeError ? "error" : probing ? "checking" : links.length > 1 ? "several" : "empty";

  return (
    <>
      <section className="card composer">
        {/* 1. The link */}
        <div className="linkrow">
          <textarea
            className="input"
            dir="auto"
            rows={3}
            spellCheck={false}
            value={draft}
            placeholder={t("dl.placeholder")}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) submit();
            }}
          />
          <div className="linkbtns">
            <button className="btn" onClick={paste}>{t("dl.paste")}</button>
            <button className="btn" onClick={() => setDraft("")} disabled={!draft}>{t("dl.clear")}</button>
          </div>
        </div>

        {/* 2. Preview: quiet when empty, a skeleton while checking, a card when found */}
        <div className={`preview ${previewState}`} key={previewState === "card" ? `card:${links[0]}` : previewState}>
          {previewState === "card" && info && (
            <>
              {info.thumbnail ? (
                <img className="thumb" src={info.thumbnail} referrerPolicy="no-referrer" alt="" />
              ) : (
                <div className="thumb ph" />
              )}
              <div className="grow">
                <div className="title" dir="auto">{info.title}</div>
                <div className="muted small stats">
                  {info.platform && <span dir="ltr">{info.platform}</span>}
                  {info.uploader && <span dir="auto">{info.uploader}</span>}
                  {info.duration ? <span dir="ltr">{fmtDuration(info.duration)}</span> : null}
                  {maxHeight ? <span>{t("preview.upTo", { h: maxHeight })}</span> : null}
                </div>
              </div>
            </>
          )}
          {previewState === "checking" && (
            <>
              <div className="thumb sk" />
              <div className="grow" aria-label={t("preview.checking")}>
                <div className="sk-line wide" />
                <div className="sk-line" />
              </div>
            </>
          )}
          {previewState === "error" && <span>{probeError}</span>}
          {previewState === "several" && <span>{t("preview.several", { n: links.length })}</span>}
          {previewState === "empty" && <span>{t("preview.empty")}</span>}
        </div>

        {/* 3. The one thing to press */}
        <button className={"cta" + (canDownload ? " ready" : "")} disabled={!canDownload} onClick={submit}>
          <span aria-hidden="true">↓</span>
          {links.length > 1 ? t("btn.downloadN", { n: links.length }) : t("btn.download")}
        </button>

        {/* 4. Everything else, one click away */}
        <div className="adv-wrap">
          <button
            className="adv-toggle"
            aria-expanded={advancedOpen}
            aria-controls="advanced-options"
            onClick={() => setAdvancedOpen(!advancedOpen)}
          >
            <span>{t("adv.toggle")}</span>
            <span className="chev" aria-hidden="true">▾</span>
          </button>
          <Collapse open={advancedOpen}>
            <AdvancedOptions maxHeight={maxHeight} linkCount={links.length} issue={issue} />
          </Collapse>
        </div>
      </section>

      {/* Queue */}
      <section className="queue">
        <div className="queue-head">
          <h2>{t("queue.title")}</h2>
          <div className="queue-tools">
            {tasks.length > 0 && (
              <button className="linkbtn quiet" aria-expanded={logsOpen} onClick={() => setLogsOpen(!logsOpen)}>
                {logsOpen ? t("btn.hideDetails") : t("btn.details")}
              </button>
            )}
            {hasFinished && <button className="linkbtn quiet" onClick={clearFinished}>{t("queue.clear")}</button>}
          </div>
        </div>
        <Collapse open={logsOpen && tasks.length > 0}>
          <pre className="logs" dir="ltr">
            {logTask && logTask.logs.length ? logTask.logs.join("\n") : t("logs.empty")}
          </pre>
        </Collapse>
        {tasks.length === 0 ? (
          <p className="empty">{t("queue.empty")}</p>
        ) : (
          <ul className="list">{tasks.map((x) => <DownloadRow key={x.id} task={x} />)}</ul>
        )}
      </section>
    </>
  );
}

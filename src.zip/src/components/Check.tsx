import type { ReactNode } from "react";

/** A labelled checkbox. The label sits on the start side, so it mirrors correctly in RTL. */
export default function Check({
  checked, onChange, children, disabled,
}: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode; disabled?: boolean }) {
  return (
    <label className={"check" + (disabled ? " disabled" : "")}>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span>{children}</span>
    </label>
  );
}

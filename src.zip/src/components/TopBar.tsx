import { useEffect, useState, type CSSProperties } from "react";
import { getVersion } from "@tauri-apps/api/app";
import { persist } from "../lib/actions";
import { useT } from "../i18n";
import { useStore } from "../store";

/**
 * Kept left-to-right in both languages so the controls and the FAQ button stay put when the
 * language flips; the text inside each button still renders in the right direction.
 */
export default function TopBar() {
  const t = useT();
  const settings = useStore((s) => s.settings);
  const setFaqOpen = useStore((s) => s.setFaqOpen);
  const [version, setVersion] = useState("");

  useEffect(() => {
    getVersion().then(setVersion).catch(() => {});
  }, []);

  if (!settings) return null;
  const dark = settings.theme === "dark";
  const lang = settings.lang ?? "en";

  return (
    <header className="top" dir="ltr">
      <div className="brand">
        <span className="wordmark">سراب</span>
        <span className="latin">SARAB</span>
      </div>

      <div className="tools">
        <div className="seg" role="group" aria-label="Language" style={{ "--i": lang === "ar" ? 1 : 0 } as CSSProperties}>
          <span className="seg-thumb" aria-hidden="true" />
          <button className={lang === "en" ? "on" : ""} aria-pressed={lang === "en"} onClick={() => persist({ lang: "en" })}>
            {t("lang.en")}
          </button>
          <button className={lang === "ar" ? "on" : ""} aria-pressed={lang === "ar"} onClick={() => persist({ lang: "ar" })}>
            {t("lang.ar")}
          </button>
        </div>

        <button className="pill" onClick={() => persist({ theme: dark ? "light" : "dark" })}>
          <span className="theme-ic" key={dark ? "d" : "l"} aria-hidden="true">{dark ? "☀" : "☾"}</span>{" "}
          {dark ? t("theme.light") : t("theme.dark")}
        </button>

        {version && <span className="ver" dir="ltr">v{version}</span>}

        <button className="pill faq-btn" onClick={() => setFaqOpen(true)}>
          <span aria-hidden="true">?</span> {t("app.faq")}
        </button>
      </div>
    </header>
  );
}

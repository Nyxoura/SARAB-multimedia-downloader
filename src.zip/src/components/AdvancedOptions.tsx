import { open } from "@tauri-apps/plugin-dialog";
import { openFolder, persist } from "../lib/actions";
import type { CookieBrowser, Format, Quality } from "../lib/api";
import { baseName } from "../lib/format";
import type { TrimIssue } from "../lib/time";
import { useT } from "../i18n";
import { useStore } from "../store";
import Check from "./Check";
import TrimPanel from "./TrimPanel";

export const QUALITIES: { id: Quality; height: number }[] = [
  { id: "best", height: 0 },
  { id: "2160", height: 2160 },
  { id: "1080", height: 1080 },
  { id: "720", height: 720 },
  { id: "480", height: 480 },
];
const FORMATS: Format[] = ["mp4", "mp3", "audio"];
/** Browsers SARAB can read cookies from (yt-dlp does the reading). Firefox first: it is the one that works while open. */
const BROWSERS: CookieBrowser[] = ["firefox", "chrome", "edge"];

/** True if the pasted video has nothing at this height (so the option is greyed out). */
export const isUnavailable = (maxHeight: number | null, height: number) => maxHeight !== null && height > maxHeight;

interface Props {
  /** Tallest resolution of the previewed video, if known. */
  maxHeight: number | null;
  /** How many links are in the box: a clip only makes sense for exactly one. */
  linkCount: number;
  /** Problem with the clip times, if any (the Download button is disabled while there is one). */
  issue: TrimIssue;
}

/** Everything a beginner doesn't need on first sight: where to save, format, quality, cookies, clip. */
export default function AdvancedOptions({ maxHeight, linkCount, issue }: Props) {
  const t = useT();
  const settings = useStore((s) => s.settings)!;

  const audioOnly = settings.format !== "mp4";
  // One "Cookies" choice: nothing, a browser, or the cookies.txt picked in Settings. A browser wins over the file.
  const cookiesValue = settings.cookiesBrowser
    ? `browser:${settings.cookiesBrowser}`
    : settings.useCookies && settings.cookiesFile
      ? "file"
      : "none";

  function pickCookies(v: string) {
    if (v.startsWith("browser:")) persist({ cookiesBrowser: v.slice("browser:".length) as CookieBrowser, useCookies: false });
    else persist({ cookiesBrowser: null, useCookies: v === "file" });
  }

  async function changeFolder() {
    const dir = await open({ directory: true, multiple: false, defaultPath: settings.downloadDir ?? undefined });
    if (typeof dir === "string") persist({ downloadDir: dir });
  }

  return (
    <div className="adv" id="advanced-options">
      {/* Save location */}
      <section className="adv-group">
        <h3>{t("adv.save")}</h3>
        <div className="saverow">
          <div className="path" title={settings.downloadDir ?? ""}>{settings.downloadDir ?? ""}</div>
          <button className="btn" onClick={changeFolder}>{t("save.browse")}</button>
          <button className="btn" disabled={!settings.downloadDir} onClick={() => settings.downloadDir && openFolder(settings.downloadDir)}>
            {t("save.open")}
          </button>
        </div>
      </section>

      {/* Format, quality, cookies */}
      <section className="adv-group">
        <h3>{t("adv.output")}</h3>
        <div className="selects">
          <label className="field">
            <span className="muted small">{t("field.format")}</span>
            <select value={settings.format} onChange={(e) => persist({ format: e.target.value as Format })}>
              {FORMATS.map((f) => <option key={f} value={f}>{t(`format.${f}`)}</option>)}
            </select>
          </label>
          <label className="field">
            <span className="muted small">{t("field.quality")}</span>
            <select value={settings.quality} disabled={audioOnly} onChange={(e) => persist({ quality: e.target.value as Quality })}>
              {QUALITIES.map((q) => (
                <option key={q.id} value={q.id} disabled={isUnavailable(maxHeight, q.height)}>{t(`quality.${q.id}`)}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="muted small">{t("field.cookies")}</span>
            <select value={cookiesValue} onChange={(e) => pickCookies(e.target.value)}>
              <option value="none">{t("cookies.none")}</option>
              {BROWSERS.map((b) => (
                <option key={b} value={`browser:${b}`}>{t(`cookies.${b}`)}</option>
              ))}
              {settings.cookiesFile && <option value="file">{baseName(settings.cookiesFile)}</option>}
            </select>
          </label>
        </div>
        {settings.cookiesBrowser && <p className="hint">{t("cookies.browserHint")}</p>}
        <div className="checks">
          <Check checked={settings.singleVideo} onChange={(v) => persist({ singleVideo: v })}>{t("check.single")}</Check>
          <Check checked={settings.convertMp4} onChange={(v) => persist({ convertMp4: v })} disabled={audioOnly}>
            {t("check.convert")}
          </Check>
        </div>
      </section>

      {/* Clip */}
      <TrimPanel linkCount={linkCount} issue={issue} />
    </div>
  );
}

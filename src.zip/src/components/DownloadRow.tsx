import { useEffect, useState } from "react";
import { openFile, showInFolder } from "../lib/actions";
import { api } from "../lib/api";
import { errText } from "../lib/errors";
import { fmtEta, fmtSpeed } from "../lib/format";
import { useT } from "../i18n";
import { useStore, type Task } from "../store";

export default function DownloadRow({ task }: { task: Task }) {
  const t = useT();
  const { resetTask, dismissTasks } = useStore();
  const [cancelling, setCancelling] = useState(false);
  const active = task.status === "queued" || task.status === "downloading";
  const finalizing = task.status === "downloading" && task.percent >= 99.5;
  // Running, but no byte has arrived yet (yt-dlp starting up, asking the site): show motion instead of an empty bar.
  const waitingForData = task.status === "downloading" && task.percent <= 0;
  const { format, quality } = task.req;
  const base = format === "mp4" ? `${t("format.mp4")} · ${t(`quality.${quality}`)}` : t(`format.${format}`);
  const isClip = Boolean(task.req.trimStart || task.req.trimEnd);
  const label = isClip ? `${base} · ✂ ${task.req.trimStart ?? "0:00"}–${task.req.trimEnd ?? "…"}` : base;

  // The Cancel click is acknowledged at once; the backend needs a moment to stop yt-dlp and delete the .part file.
  useEffect(() => {
    if (!active) setCancelling(false);
  }, [active]);

  function cancel() {
    setCancelling(true);
    api.cancel(task.id).catch(() => setCancelling(false));
  }

  function retry() {
    resetTask(task.id);
    api.retry(task.req).catch(() => {});
  }

  return (
    <li className={"row" + (task.leaving ? " leaving" : "")}>
      <div className="row-in">
        <div className={`item ${task.status}${cancelling ? " cancelling" : ""}`}>
          {task.thumbnail ? (
            <img className="thumb" src={task.thumbnail} referrerPolicy="no-referrer" alt="" loading="lazy" />
          ) : (
            <div className="thumb ph" />
          )}

          <div className="grow">
            <div className="title" dir="auto">{task.title ?? task.url}</div>

            <div className="bar" role="progressbar" aria-valuenow={Math.round(task.percent)} aria-valuemin={0} aria-valuemax={100}>
              <div
                className={"fill" + (waitingForData ? " indet" : task.status === "downloading" ? " live" : "")}
                style={{ width: `${task.percent}%` }}
              />
            </div>

            <div className="stats small">
              <span className="muted">{label}</span>
              {task.status === "queued" && <span className="muted">{t("row.waiting")}</span>}
              {task.status === "downloading" && isClip && <span>{t("row.clip")}</span>}
              {task.status === "downloading" && !isClip && finalizing && <span>{t("row.finalizing")}</span>}
              {task.status === "downloading" && !isClip && !finalizing && (
                <>
                  <span>{Math.round(task.percent)}%</span>
                  {task.speed ? <span dir="ltr">{fmtSpeed(task.speed)}</span> : null}
                  {task.eta != null ? <span>{t("row.left", { t: fmtEta(task.eta) })}</span> : null}
                </>
              )}
              {task.status === "done" && (
                <span className="ok">
                  <svg className="check-ic" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5l3.2 3.2L13 5" /></svg>
                  {t("row.saved")}
                </span>
              )}
              {task.status === "cancelled" && <span className="muted">{t("row.cancelled")}</span>}
              {task.status === "error" && <span className="bad">{task.error ? errText(task.error) : ""}</span>}
            </div>

            {task.status === "error" && task.detail && <div className="detail" dir="ltr">{task.detail}</div>}

            <div className="actions">
              {active && (
                <button className="linkbtn" disabled={cancelling} onClick={cancel}>
                  {cancelling ? t("row.cancelling") : t("row.cancel")}
                </button>
              )}
              {task.status === "done" && task.filePath && (
                <>
                  <button className="linkbtn" onClick={() => openFile(task.filePath!)}>{t("row.open")}</button>
                  <button className="linkbtn" onClick={() => showInFolder(task.filePath!)}>{t("row.show")}</button>
                </>
              )}
              {(task.status === "error" || task.status === "cancelled") && (
                <button className="linkbtn" onClick={retry}>{t("row.retry")}</button>
              )}
              {!active && <button className="linkbtn quiet" onClick={() => dismissTasks([task.id])}>{t("row.remove")}</button>}
            </div>
          </div>
        </div>
      </div>
    </li>
  );
}

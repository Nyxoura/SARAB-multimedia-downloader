import { useEffect, useState, type ReactNode } from "react";

/**
 * Smoothly expands and collapses its content (CSS grid rows 0fr <-> 1fr, so the height is animated
 * without measuring anything). The content is unmounted once the collapse has finished.
 */
export default function Collapse({ open, children, ms = 340 }: { open: boolean; children: ReactNode; ms?: number }) {
  const [mounted, setMounted] = useState(open);
  const [shown, setShown] = useState(open);

  useEffect(() => {
    if (open) {
      setMounted(true);
      // Two frames: let the browser paint the collapsed state first, or there is nothing to animate from.
      let b = 0;
      const a = requestAnimationFrame(() => { b = requestAnimationFrame(() => setShown(true)); });
      return () => { cancelAnimationFrame(a); cancelAnimationFrame(b); };
    }
    setShown(false);
    const id = setTimeout(() => setMounted(false), ms);
    return () => clearTimeout(id);
  }, [open, ms]);

  if (!mounted) return null;
  return (
    <div className={"collapse" + (shown ? " open" : "")}>
      <div className="collapse-in">{children}</div>
    </div>
  );
}

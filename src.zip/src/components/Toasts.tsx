import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { openFile, showInFolder } from "../lib/actions";
import { useT } from "../i18n";
import { useStore, type Toast } from "../store";

const TOAST_MS = 8000;

function Item({ toast }: { toast: Toast }) {
  const t = useT();
  const dismiss = useStore((s) => s.dismissToast);
  useEffect(() => {
    const timer = setTimeout(() => dismiss(toast.id), TOAST_MS);
    return () => clearTimeout(timer);
  }, [toast.id, toast.text, dismiss]);

  return (
    <motion.div
      className="toast"
      role="status"
      initial={{ opacity: 0, y: 28, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 14, scale: 0.97, transition: { duration: 0.18 } }}
      transition={{ type: "spring", stiffness: 420, damping: 30 }}
    >
      <span className="toast-text" dir="auto">{toast.text}</span>
      {toast.path && (
        <>
          <button className="linkbtn" onClick={() => openFile(toast.path!)}>{t("row.open")}</button>
          <button className="linkbtn" onClick={() => showInFolder(toast.path!)}>{t("row.show")}</button>
        </>
      )}
      <button className="linkbtn quiet" aria-label={t("common.dismiss")} onClick={() => dismiss(toast.id)}>✕</button>
      <span className="toast-timer" style={{ animationDuration: `${TOAST_MS}ms` }} aria-hidden="true" />
    </motion.div>
  );
}

export default function Toasts() {
  const toasts = useStore((s) => s.toasts);
  return (
    <div className="toasts">
      <AnimatePresence initial={false}>
        {/* The text is part of the key, so a new message under the same id slides in again and restarts the timer. */}
        {toasts.map((x) => <Item key={`${x.id}:${x.text}`} toast={x} />)}
      </AnimatePresence>
    </div>
  );
}

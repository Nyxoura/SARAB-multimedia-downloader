import { useState, type CSSProperties } from "react";
import { openFile, showInFolder, notify } from "../lib/actions";
import { api } from "../lib/api";
import { errText } from "../lib/errors";
import { fmtDate } from "../lib/format";
import { LEAVE_MS, sleep } from "../lib/motion";
import { useLang, useT } from "../i18n";
import { useStore } from "../store";

export default function HistoryTab() {
  const t = useT();
  const lang = useLang();
  const { history, setHistory } = useStore();
  const [leaving, setLeaving] = useState<Set<string>>(new Set());
  const refresh = () => api.getHistory().then(setHistory).catch(() => {});

  async function remove(id: string) {
    setLeaving((s) => new Set(s).add(id));
    await sleep(LEAVE_MS);
    await api.removeHistory(id).catch(() => {});
    await refresh();
    setLeaving((s) => { const n = new Set(s); n.delete(id); return n; });
  }
  async function clearAll() {
    setLeaving(new Set(history.map((h) => h.id)));
    await sleep(LEAVE_MS);
    await api.clearHistory().catch(() => {});
    await refresh();
    setLeaving(new Set());
  }
  async function again(url: string) {
    try {
      await api.enqueue([url]);
      useStore.getState().setTab("download");
    } catch (e) {
      notify(errText(e), "enqueue-error");
    }
  }

  return (
    <section className="queue">
      <div className="queue-head">
        <h2>{t("history.title")}</h2>
        {history.length > 0 && <button className="linkbtn quiet" onClick={clearAll}>{t("history.clear")}</button>}
      </div>

      {history.length === 0 ? (
        <p className="empty">{t("history.empty")}</p>
      ) : (
        <ul className="list">
          {history.map((h, i) => (
            <li className={"row" + (leaving.has(h.id) ? " leaving" : "")} key={h.id} style={{ "--n": Math.min(i, 8) } as CSSProperties}>
              <div className="row-in">
                <div className="item done">
                  {h.thumbnail ? (
                    <img className="thumb" src={h.thumbnail} referrerPolicy="no-referrer" alt="" loading="lazy" />
                  ) : (
                    <div className="thumb ph" />
                  )}
                  <div className="grow">
                    <div className="title" dir="auto">{h.title}</div>
                    <div className="stats small muted">
                      <span>{h.format === "mp4" ? `${t("format.mp4")} · ${t(`quality.${h.quality}`)}` : t(`format.${h.format}`)}</span>
                      <span>{fmtDate(h.finishedAt, lang)}</span>
                    </div>
                    <div className="actions">
                      {h.filePath && (
                        <>
                          <button className="linkbtn" onClick={() => openFile(h.filePath!)}>{t("row.open")}</button>
                          <button className="linkbtn" onClick={() => showInFolder(h.filePath!)}>{t("row.show")}</button>
                        </>
                      )}
                      <button className="linkbtn" onClick={() => again(h.url)}>{t("history.again")}</button>
                      <button className="linkbtn quiet" onClick={() => remove(h.id)}>{t("row.remove")}</button>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

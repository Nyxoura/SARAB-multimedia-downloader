import { useCallback } from "react";
import type { Lang } from "../lib/api";
import { useStore } from "../store";
import { ar, en, type Key } from "./dict";

export type { Key };
type Vars = Record<string, string | number>;

export const isRtl = (lang: Lang) => lang === "ar";

/** First launch: follow the system language, Arabic if it is Arabic, English otherwise. */
export function detectLang(): Lang {
  return (navigator.language ?? "").toLowerCase().startsWith("ar") ? "ar" : "en";
}

export function translate(lang: Lang, key: string, vars?: Vars): string {
  const table = (lang === "ar" ? ar : en) as Record<string, string>;
  let s = table[key] ?? (en as Record<string, string>)[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
  return s;
}

export const currentLang = (): Lang => useStore.getState().settings?.lang ?? detectLang();

/** Translate outside React (event listeners, actions). */
export const tr = (key: string, vars?: Vars) => translate(currentLang(), key, vars);

export function useLang(): Lang {
  return useStore((s) => s.settings?.lang ?? detectLang());
}

/** Translate inside React. Re-renders when the language changes. */
export function useT() {
  const lang = useLang();
  return useCallback((key: Key, vars?: Vars) => translate(lang, key, vars), [lang]);
}

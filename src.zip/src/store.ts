import { create } from "zustand";
import { LEAVE_MS } from "./lib/motion";
import type { DownloadRequest, HistoryEntry, Settings, Status, Update } from "./lib/api";

export type Tab = "download" | "history" | "settings";

export interface Task {
  id: string;
  url: string;
  /** Exactly what was submitted, so Retry repeats it with the same options. */
  req: DownloadRequest;
  status: Status;
  percent: number;
  title?: string;
  thumbnail?: string;
  speed?: number;
  eta?: number;
  filePath?: string;
  error?: string;
  /** yt-dlp's own wording for the error (sign-in requests and vague failures). */
  detail?: string;
  logs: string[];
  /** Set while the row plays its exit animation; the task is removed right after. */
  leaving?: boolean;
}
export interface Toast {
  id: string;
  text: string;
  path?: string;
}

interface State {
  settings: Settings | null;
  tasks: Task[];
  toasts: Toast[];
  history: HistoryEntry[];
  tab: Tab;
  /** Text in the link box. Lives here so clipboard detection can fill it. */
  draft: string;
  faqOpen: boolean;
  logsOpen: boolean;
  /** "Advanced options" panel on the Download tab. Collapsed by default. */
  advancedOpen: boolean;
  /** Optional clip times typed by the user; sent with the next download only. */
  trimStart: string;
  trimEnd: string;
  setSettings: (s: Settings) => void;
  setHistory: (h: HistoryEntry[]) => void;
  setTab: (t: Tab) => void;
  setDraft: (d: string) => void;
  setFaqOpen: (o: boolean) => void;
  setLogsOpen: (o: boolean) => void;
  setAdvancedOpen: (o: boolean) => void;
  setTrim: (start: string, end: string) => void;
  addTask: (t: Task) => void;
  resetTask: (id: string) => void;
  applyUpdate: (u: Update) => void;
  appendLog: (id: string, line: string) => void;
  removeTask: (id: string) => void;
  /** Remove rows with an exit animation. */
  dismissTasks: (ids: string[]) => void;
  clearFinished: () => void;
  pushToast: (t: Toast) => void;
  dismissToast: (id: string) => void;
}

export const useStore = create<State>((set, get) => ({
  settings: null,
  tasks: [],
  toasts: [],
  history: [],
  tab: "download",
  draft: "",
  faqOpen: false,
  logsOpen: false,
  advancedOpen: false,
  trimStart: "",
  trimEnd: "",
  setSettings: (settings) => set({ settings }),
  setHistory: (history) => set({ history }),
  setTab: (tab) => set({ tab }),
  setDraft: (draft) => set({ draft }),
  setFaqOpen: (faqOpen) => set({ faqOpen }),
  setLogsOpen: (logsOpen) => set({ logsOpen }),
  setAdvancedOpen: (advancedOpen) => set({ advancedOpen }),
  setTrim: (trimStart, trimEnd) => set({ trimStart, trimEnd }),
  // Appended, not prepended: the list reads in the same order the downloads run.
  addTask: (t) => set((s) => ({ tasks: [...s.tasks, t] })),
  resetTask: (id) =>
    set((s) => ({
      tasks: s.tasks.map((t) =>
        t.id === id
          ? { ...t, status: "queued", percent: 0, speed: undefined, eta: undefined, error: undefined, detail: undefined, logs: [], leaving: false }
          : t,
      ),
    })),
  applyUpdate: (u) =>
    set((s) => ({
      tasks: s.tasks.map((t) =>
        t.id !== u.id
          ? t
          : {
              ...t,
              status: u.status,
              percent: u.percent ?? t.percent,
              speed: u.speed ?? undefined,
              eta: u.eta ?? undefined,
              title: u.title ?? t.title,
              thumbnail: u.thumbnail ?? t.thumbnail,
              filePath: u.filePath ?? t.filePath,
              error: u.error ?? t.error,
              detail: u.detail ?? t.detail,
            },
      ),
    })),
  appendLog: (id, line) =>
    set((s) => ({
      tasks: s.tasks.map((t) => (t.id === id ? { ...t, logs: [...t.logs, line].slice(-400) } : t)),
    })),
  removeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
  dismissTasks: (ids) => {
    set((s) => ({ tasks: s.tasks.map((t) => (ids.includes(t.id) ? { ...t, leaving: true } : t)) }));
    // Only rows still marked as leaving are removed (a quick Retry cancels the removal).
    setTimeout(() => set((s) => ({ tasks: s.tasks.filter((t) => !(ids.includes(t.id) && t.leaving)) })), LEAVE_MS);
  },
  clearFinished: () => {
    const ids = get().tasks.filter((t) => t.status !== "queued" && t.status !== "downloading").map((t) => t.id);
    get().dismissTasks(ids);
  },
  pushToast: (t) => set((s) => ({ toasts: [...s.toasts.filter((x) => x.id !== t.id), t] })),
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));
